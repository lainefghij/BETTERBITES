
const sampleInquiries = {
  "1": {
    reference: "INQ-2026-001",
    submitted: "Oct 10, 2026 10:30 AM",
    name: "Guiguinto NHS",
    contactPerson: "Ms. Maria Santos",
    phone: "0992 345 6789",
    email: "principal@g-nhs.edu.ph",
    address: "Poblacion, Guiguinto, Bulacan",
    event: "School Feeding Program",
    preferredDate: "October 15, 2026",
    delivery: "Delivery",
    message: "We would like to inquire about bulk orders for our upcoming feeding program. Please send us the available options and quotation.",
    items: [{ name: "Blueberry Muffins", image: "images/featured-product.png", quantity: 50, unitPrice: 45 }],
    status: "Pending",
    notes: ""
  },
  "2": {
    reference: "INQ-2026-002",
    submitted: "Oct 9, 2026 3:15 PM",
    name: "Barangay Sta. Cruz",
    contactPerson: "Mr. Juan Reyes",
    phone: "0917 123 4567",
    email: "barangay@example.com",
    address: "Sta. Cruz, Bulacan",
    event: "Community Event",
    preferredDate: "October 18, 2026",
    delivery: "Pick-up",
    message: "We need bread for our community event. Please confirm availability.",
    items: [{ name: "Banana Bread", image: "images/featured-product.png", quantity: 30, unitPrice: 30 }],
    status: "Confirmed",
    notes: ""
  },
  "3": {
    reference: "INQ-2026-003",
    submitted: "Oct 8, 2026 11:20 AM",
    name: "Lois Dela Cruz",
    contactPerson: "Lois Dela Cruz",
    phone: "0918 222 3344",
    email: "lois@example.com",
    address: "Guiguinto, Bulacan",
    event: "Personal Order",
    preferredDate: "October 12, 2026",
    delivery: "Pick-up",
    message: "I would like to order snacks for a family gathering.",
    items: [{ name: "Cheese Rolls", image: "images/featured-product.png", quantity: 12, unitPrice: 40 }],
    status: "Processing",
    notes: ""
  },
  "4": {
    reference: "INQ-2026-004",
    submitted: "Oct 7, 2026 9:45 AM",
    name: "Holy Family Parish",
    contactPerson: "Parish Coordinator",
    phone: "0920 555 1234",
    email: "parish@example.com",
    address: "Guiguinto, Bulacan",
    event: "Parish Activity",
    preferredDate: "October 20, 2026",
    delivery: "Delivery",
    message: "We need assorted baked products for our parish activity.",
    items: [{ name: "Ensaymada", image: "images/featured-product.png", quantity: 40, unitPrice: 50 }],
    status: "Confirmed",
    notes: ""
  },
  "5": {
    reference: "INQ-2026-005",
    submitted: "Oct 6, 2026 1:10 PM",
    name: "ABC Learning Center",
    contactPerson: "School Coordinator",
    phone: "0919 333 4567",
    email: "abc@example.com",
    address: "Guiguinto, Bulacan",
    event: "School Event",
    preferredDate: "October 9, 2026",
    delivery: "Delivery",
    message: "Please prepare cookies for our school event.",
    items: [{ name: "Cookies", image: "images/featured-product.png", quantity: 100, unitPrice: 15 }],
    status: "Completed",
    notes: ""
  }
};

const storageKey = "nutriShowcaseInquiryChanges";
const inquiryId = new URLSearchParams(window.location.search).get("id") || "1";

function getChanges() {
  try {
    return JSON.parse(sessionStorage.getItem(storageKey) || "{}");
  } catch {
    return {};
  }
}

function money(value) {
  return value.toLocaleString("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

const original = sampleInquiries[inquiryId];

if (!original || getChanges()[inquiryId]?.deleted) {
  document.getElementById("detailsShell").innerHTML = `
    <div style="padding:40px;text-align:center">
      <h2>Inquiry not found</h2>
      <p>This sample inquiry is not available.</p>
      <a href="inquiry-management.html">Back to Inquiries</a>
    </div>
  `;
} else {
  const saved = getChanges()[inquiryId] || {};
  const inquiry = {
    ...original,
    status: saved.status || original.status,
    notes: saved.notes || ""
  };

  function renderDetails() {
    document.getElementById("referenceNo").textContent = inquiry.reference;
    document.getElementById("submittedDate").textContent = inquiry.submitted;
    document.getElementById("customerName").textContent = inquiry.name;
    document.getElementById("contactPerson").textContent = inquiry.contactPerson;
    document.getElementById("phone").textContent = inquiry.phone;
    document.getElementById("email").textContent = inquiry.email;
    document.getElementById("address").textContent = inquiry.address;
    document.getElementById("eventPurpose").textContent = inquiry.event;
    document.getElementById("preferredDate").textContent = inquiry.preferredDate;
    document.getElementById("delivery").textContent = inquiry.delivery;
    document.getElementById("customerMessage").textContent = inquiry.message;

    document.getElementById("statusSelect").value = inquiry.status;
    document.getElementById("updateStatus").value = inquiry.status;
    document.getElementById("adminNotes").value = inquiry.notes;

    document.getElementById("orderedItems").innerHTML = inquiry.items.map((item, index) => `
      <tr>
        <td>${index + 1}</td>
        <td><strong>${item.name}</strong></td>
        <td><img class="product-image" src="${item.image}" alt="${item.name}" onerror="this.style.visibility='hidden'"></td>
        <td>${item.quantity} pcs</td>
        <td>${money(item.unitPrice)}</td>
        <td>${money(item.quantity * item.unitPrice)}</td>
      </tr>
    `).join("");

    const total = inquiry.items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
    document.getElementById("totalAmount").textContent = `₱ ${money(total)}`;
  }

  document.getElementById("statusSelect").addEventListener("change", event => {
    document.getElementById("updateStatus").value = event.target.value;
  });

  document.getElementById("updateStatus").addEventListener("change", event => {
    document.getElementById("statusSelect").value = event.target.value;
  });

  document.getElementById("saveChanges").addEventListener("click", () => {
    inquiry.status = document.getElementById("updateStatus").value;
    inquiry.notes = document.getElementById("adminNotes").value.trim();

    try {
      const changes = getChanges();
      changes[inquiryId] = {
        ...changes[inquiryId],
        status: inquiry.status,
        notes: inquiry.notes
      };

      sessionStorage.setItem(storageKey, JSON.stringify(changes));

      const message = document.getElementById("saveMessage");
      message.textContent = "Changes saved for this browser session.";
      message.style.color = "#267340";
    } catch {
      const message = document.getElementById("saveMessage");
      message.textContent = "Unable to save changes. Please try again.";
      message.style.color = "#b9382c";
    }
  });

  renderDetails();
}
