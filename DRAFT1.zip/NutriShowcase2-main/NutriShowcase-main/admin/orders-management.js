import { auth, db } from "../firebase/firebase.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import {
    collection,
    doc,
    getDoc,
    onSnapshot,
    runTransaction,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

document.addEventListener("DOMContentLoaded", () => {
    const $ = id => document.getElementById(id);

    const STATUS_LABELS = {
        pending: "Pending",
        confirmed: "Confirmed",
        preparing: "Preparing",
        ready: "Ready / On the way",
        completed: "Completed",
        cancelled: "Cancelled"
    };

    let orders = [];
    let selectedId = null;
    let unsubscribe = null;
    let toastTimer;

    const tableBody = $("orderTableBody");
    const modal = $("orderModal");
    const sidebar = $("sidebar");
    const overlay = $("sidebarOverlay");

    /* ---------- helpers ---------- */

    function toast(message, type = "") {
        const el = $("adminToast");
        el.textContent = message;
        el.className = "admin-toast show " + type;
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => el.classList.remove("show"), 3000);
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, c => ({
            "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
        })[c]);
    }

    function peso(value) {
        return "₱" + Number(value || 0).toLocaleString("en-PH", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function millis(value) {
        if (!value) return Date.now(); // pending server timestamp = just now
        if (value.toMillis) return value.toMillis();
        const t = new Date(value).getTime();
        return Number.isNaN(t) ? 0 : t;
    }

    function formatDate(value, withTime = false) {
        const date = new Date(millis(value));
        return date.toLocaleString("en-PH", withTime
            ? { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" }
            : { month: "short", day: "numeric", year: "numeric" });
    }

    function statusText(order) {
        if (order.status === "ready") {
            return order.fulfillment === "delivery" ? "Out for delivery" : "Ready for pickup";
        }
        return STATUS_LABELS[order.status] || order.status || "Pending";
    }

    function itemsSummary(order) {
        const items = order.items || [];
        if (!items.length) return "—";
        const first = `${items[0].quantity}× ${items[0].name}`;
        return items.length > 1 ? `${first} +${items.length - 1} more` : first;
    }

    /* ---------- render ---------- */

    function updateSummary() {
        const active = ["confirmed", "preparing", "ready"];
        const pending = orders.filter(o => o.status === "pending").length;

        $("totalOrders").textContent = orders.length;
        $("pendingOrders").textContent = pending;
        $("activeOrders").textContent = orders.filter(o => active.includes(o.status)).length;
        $("revenueTotal").textContent = peso(
            orders.filter(o => o.status === "completed").reduce((s, o) => s + (Number(o.total) || 0), 0)
        );

        $("notificationDot").hidden = pending === 0;
    }

    function renderOrders() {
        const term = $("searchInput").value.trim().toLowerCase();
        const status = $("statusFilter").value;
        const sort = $("sortFilter").value;

        const filtered = orders
            .filter(o => {
                const text = [o.orderNumber, o.customerName, o.email, o.contactNumber, itemsSummary(o)]
                    .join(" ").toLowerCase();
                return text.includes(term) && (status === "all" || o.status === status);
            })
            .sort((a, b) => sort === "newest"
                ? millis(b.createdAt) - millis(a.createdAt)
                : millis(a.createdAt) - millis(b.createdAt));

        tableBody.innerHTML = filtered.map(o => `
            <tr>
                <td><span class="inquiry-number">${escapeHTML(o.orderNumber || o.id)}</span></td>
                <td>
                    <div class="customer-cell">
                        <strong>${escapeHTML(o.customerName)}</strong>
                        <small>${escapeHTML(o.contactNumber)}</small>
                    </div>
                </td>
                <td>${escapeHTML(itemsSummary(o))}</td>
                <td>
                    ${escapeHTML(o.preferredDate || "—")}<br>
                    <small>${o.fulfillment === "delivery" ? "Delivery" : "Pickup"}</small>
                </td>
                <td><strong>${peso(o.total)}</strong><br><small>${o.paymentStatus === "paid" ? "Paid" : "Unpaid"}</small></td>
                <td><span class="status ${escapeHTML(o.status)}">${escapeHTML(statusText(o))}</span></td>
                <td><button class="view-button" data-id="${escapeHTML(o.id)}">Manage</button></td>
            </tr>`).join("");

        $("emptyState").hidden = filtered.length !== 0;
        $("resultCount").textContent = `Showing ${filtered.length} of ${orders.length} orders`;
        updateSummary();
    }

    /* ---------- modal ---------- */

    function openOrder(id) {
        const o = orders.find(x => x.id === id);
        if (!o) return;

        selectedId = id;

        $("detailOrderNumber").textContent = o.orderNumber || o.id;
        $("detailName").textContent = o.customerName || "—";
        $("detailEmail").textContent = o.email || "—";
        $("detailPhone").textContent = o.contactNumber || "—";
        $("detailDate").textContent = formatDate(o.createdAt, true);
        $("detailFulfillment").textContent = o.fulfillment === "delivery" ? "Delivery" : "Pickup";
        $("detailSchedule").textContent = `${o.preferredDate || "—"} ${o.preferredTime || ""}`.trim();
        $("detailPayment").textContent = o.paymentMethod === "gcash" ? "GCash" : "Cash";
        $("detailAddress").textContent = o.fulfillment === "delivery" ? (o.address || "—") : "Pickup at shop";

        $("detailItems").innerHTML = (o.items || []).map(i => `
            <tr>
                <td>${escapeHTML(i.name)}</td>
                <td>${Number(i.quantity) || 0}</td>
                <td>${peso(i.price)}</td>
                <td>${peso(i.lineTotal ?? i.price * i.quantity)}</td>
            </tr>`).join("");

        $("detailTotals").innerHTML = `
            <tr><td colspan="3">Subtotal</td><td>${peso(o.subtotal)}</td></tr>
            <tr><td colspan="3">Delivery fee</td><td>${peso(o.deliveryFee)}</td></tr>
            <tr><td colspan="3">Total</td><td>${peso(o.total)}</td></tr>`;

        $("detailNotes").textContent = o.notes || "No notes.";
        $("detailStatus").value = o.status || "pending";
        $("detailPaymentStatus").value = o.paymentStatus || "unpaid";
        $("adminNotes").value = o.adminNotes || "";

        const locked = o.status === "cancelled";
        $("detailStatus").disabled = locked;
        $("cancelLock").hidden = !locked;

        modal.classList.add("show");
        document.body.style.overflow = "hidden";
    }

    function closeModal() {
        modal.classList.remove("show");
        document.body.style.overflow = "";
        selectedId = null;
    }

    async function saveOrder() {
        const old = orders.find(o => o.id === selectedId);
        if (!old) return;

        const status = $("detailStatus").value;
        const paymentStatus = $("detailPaymentStatus").value;
        const adminNotes = $("adminNotes").value.trim();
        const cancelling = old.status !== "cancelled" && status === "cancelled";

        if (cancelling && !confirm("Cancel this order and return its items to stock?")) return;

        const button = $("saveOrder");
        button.disabled = true;
        button.textContent = "Saving...";

        try {
            const orderRef = doc(db, "orders", old.id);

            await runTransaction(db, async tx => {
                const orderSnap = await tx.get(orderRef);
                if (!orderSnap.exists()) throw new Error("This order no longer exists.");

                const current = orderSnap.data();

                if (current.status === "cancelled" && status !== "cancelled") {
                    throw new Error("A cancelled order cannot be reopened.");
                }

                const restoring = current.status !== "cancelled" && status === "cancelled";
                const productSnaps = [];

                if (restoring) {
                    for (const item of current.items || []) {
                        const ref = doc(db, "products", item.productId);
                        productSnaps.push({ ref, snap: await tx.get(ref), quantity: Number(item.quantity) || 0 });
                    }
                }

                productSnaps.forEach(({ ref, snap, quantity }) => {
                    if (snap.exists()) {
                        tx.update(ref, {
                            stock: (Number(snap.data().stock) || 0) + quantity,
                            updatedAt: serverTimestamp()
                        });
                    }
                });

                tx.update(orderRef, {
                    status,
                    paymentStatus,
                    adminNotes,
                    updatedAt: serverTimestamp()
                });
            });

            closeModal();
            toast(cancelling ? "Order cancelled and stock restored." : "Order updated.");

        } catch (error) {
            console.error("Order save error:", error);
            toast(error.code === "permission-denied"
                ? "Permission denied. Check Firestore rules and admin role."
                : (error.message || "Unable to update the order."), "error");
        } finally {
            button.disabled = false;
            button.textContent = "Save Changes";
        }
    }

    function exportCSV() {
        if (!orders.length) {
            toast("There are no orders to export.", "error");
            return;
        }

        const headers = ["Order No", "Date", "Customer", "Email", "Phone", "Type", "Address", "Needed On",
            "Items", "Subtotal", "Delivery Fee", "Total", "Payment Method", "Payment Status", "Status", "Customer Notes", "Internal Notes"];

        const rows = orders.map(o => [
            o.orderNumber || o.id, formatDate(o.createdAt, true), o.customerName, o.email, o.contactNumber,
            o.fulfillment, o.address, `${o.preferredDate || ""} ${o.preferredTime || ""}`.trim(),
            (o.items || []).map(i => `${i.quantity}x ${i.name}`).join("; "),
            o.subtotal, o.deliveryFee, o.total, o.paymentMethod, o.paymentStatus, o.status, o.notes, o.adminNotes
        ]);

        const csv = [headers, ...rows]
            .map(row => row.map(v => `"${String(v ?? "").replace(/"/g, '""')}"`).join(","))
            .join("\n");

        const url = URL.createObjectURL(new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" }));
        const link = document.createElement("a");
        link.href = url;
        link.download = "BETTERBITES-Orders.csv";
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
    }

    /* ---------- events ---------- */

    tableBody.addEventListener("click", event => {
        const button = event.target.closest(".view-button");
        if (button) openOrder(button.dataset.id);
    });

    $("searchInput").addEventListener("input", renderOrders);
    $("statusFilter").addEventListener("change", renderOrders);
    $("sortFilter").addEventListener("change", renderOrders);
    $("closeModal").addEventListener("click", closeModal);
    $("cancelModal").addEventListener("click", closeModal);
    $("saveOrder").addEventListener("click", saveOrder);
    $("exportButton").addEventListener("click", exportCSV);
    modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });

    // completing an order usually means it was paid
    $("detailStatus").addEventListener("change", () => {
        if ($("detailStatus").value === "completed") $("detailPaymentStatus").value = "paid";
    });

    $("notificationButton").addEventListener("click", () => {
        const pending = orders.filter(o => o.status === "pending").length;
        toast(pending ? `${pending} order(s) waiting for confirmation.` : "No pending orders.");
    });

    function closeSidebar() {
        sidebar.classList.remove("open");
        overlay.classList.remove("show");
    }

    $("menuToggle").addEventListener("click", () => {
        sidebar.classList.toggle("open");
        overlay.classList.toggle("show");
    });
    overlay.addEventListener("click", closeSidebar);

    document.addEventListener("keydown", event => {
        if (event.key === "Escape") { closeModal(); closeSidebar(); }
    });

    $("profileButton").addEventListener("click", event => {
        event.stopPropagation();
        $("profileDropdown").classList.toggle("show");
    });
    document.addEventListener("click", event => {
        if (!event.target.closest(".profile-container")) $("profileDropdown").classList.remove("show");
    });

    async function logout(event) {
        event?.preventDefault();
        if (!confirm("Are you sure you want to log out?")) return;
        try {
            if (unsubscribe) unsubscribe();
            await signOut(auth);
            location.href = "admin-login.html";
        } catch (error) {
            toast("Unable to log out.", "error");
        }
    }

    $("logoutButton").addEventListener("click", logout);
    $("dropdownLogout").addEventListener("click", logout);

    /* ---------- auth + live data ---------- */

    onAuthStateChanged(auth, async user => {
        if (!user) {
            location.replace("admin-login.html");
            return;
        }

        try {
            const snap = await getDoc(doc(db, "users", user.uid));
            const profile = snap.exists() ? snap.data() : null;

            if (!profile || profile.role !== "admin" || profile.status !== "active") {
                await signOut(auth);
                location.replace("admin-login.html");
                return;
            }

            document.querySelector(".profile-name").textContent = profile.fullName || "Admin";
            document.querySelector(".profile-avatar").textContent = (profile.fullName || "A").charAt(0).toUpperCase();

            tableBody.innerHTML = `<tr><td colspan="7">Loading orders...</td></tr>`;

            unsubscribe = onSnapshot(collection(db, "orders"), snapshot => {
                orders = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
                renderOrders();
            }, error => {
                console.error("Orders listener error:", error);
                tableBody.innerHTML = `<tr><td colspan="7">Unable to load orders. ${
                    error.code === "permission-denied" ? "Check your Firestore rules." : "Please refresh."}</td></tr>`;
            });

        } catch (error) {
            console.error("Admin verification error:", error);
            toast("Unable to verify admin access.", "error");
        }
    });
});
