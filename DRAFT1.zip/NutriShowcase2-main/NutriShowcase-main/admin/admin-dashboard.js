import { auth, db } from "../firebase/firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";

import {
    collection,
    doc,
    getDoc,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

const sidebar = document.getElementById("sidebar");
const menuToggle = document.getElementById("menuToggle");
const sidebarOverlay = document.getElementById("sidebarOverlay");

const profileButton = document.getElementById("profileButton");
const profileDropdown = document.getElementById("profileDropdown");

const notificationButton = document.getElementById("notificationButton");
const logoutButton = document.getElementById("logoutButton");
const dropdownLogout = document.getElementById("dropdownLogout");

const totalProducts = document.getElementById("totalProducts");
const totalProcesses = document.getElementById("totalProcesses");
const totalInquiries = document.getElementById("totalInquiries");
const totalOrders = document.getElementById("totalOrders");

const chartTotal = document.getElementById("chartTotal");
const breadCount = document.getElementById("breadCount");
const muffinCount = document.getElementById("muffinCount");
const cookieCount = document.getElementById("cookieCount");

const recentOrders = document.getElementById("recentOrders");

let inquiryCount = 0;
let pendingOrders = 0;

menuToggle?.addEventListener("click", () => {
    sidebar?.classList.toggle("open");
    sidebarOverlay?.classList.toggle("show");
});

sidebarOverlay?.addEventListener("click", () => {
    sidebar?.classList.remove("open");
    sidebarOverlay?.classList.remove("show");
});

document.querySelectorAll(".sidebar-nav .nav-link").forEach(link => {
    link.addEventListener("click", () => {
        sidebar?.classList.remove("open");
        sidebarOverlay?.classList.remove("show");
    });
});

profileButton?.addEventListener("click", event => {
    event.stopPropagation();

    const isOpen = profileDropdown?.classList.toggle("show");

    profileButton.setAttribute("aria-expanded", String(isOpen));
});

document.addEventListener("click", event => {
    if (
        !profileDropdown?.contains(event.target) &&
        !profileButton?.contains(event.target)
    ) {
        profileDropdown?.classList.remove("show");
        profileButton?.setAttribute("aria-expanded", "false");
    }
});

document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
        profileDropdown?.classList.remove("show");
        profileButton?.setAttribute("aria-expanded", "false");
    }
});

notificationButton?.addEventListener("click", () => {
    alert(`${pendingOrders} order(s) waiting for confirmation. ${inquiryCount} customer inquiries in total.`);
});

async function handleLogout(event) {
    event.preventDefault();

    const confirmLogout = confirm("Are you sure you want to log out?");

    if (!confirmLogout) return;

    try {
        await signOut(auth);
        window.location.href = "admin-login.html";
    } catch (error) {
        console.error("Logout error:", error);
        alert("Unable to log out. Please try again.");
    }
}

logoutButton?.addEventListener("click", handleLogout);
dropdownLogout?.addEventListener("click", handleLogout);

window.addEventListener("resize", () => {
    if (window.innerWidth > 700) {
        sidebar?.classList.remove("open");
        sidebarOverlay?.classList.remove("show");
    }
});

function setAdminProfile(adminData, user) {
    const profileName = document.querySelector(".profile-name");
    const profileAvatar = document.querySelector(".profile-avatar");
    const profileRole = document.querySelector(".profile-role");
    const welcomeHeading = document.querySelector(".welcome-text h2");

    if (profileName) {
        profileName.textContent = "Admin";
    }

    if (profileAvatar) {
        profileAvatar.textContent = "B";
    }

    if (profileRole) {
        profileRole.textContent = "Administrator";
    }

    if (welcomeHeading) {
        welcomeHeading.textContent = `Welcome, ${adminData.fullName || "Admin"}!`;
    }

    profileButton?.setAttribute(
        "aria-label",
        `Admin profile (${user.email || ""})`
    );

    profileButton?.setAttribute("aria-expanded", "false");
}

function showDashboardError(message) {
    console.error(message);

    if (totalProducts) totalProducts.textContent = "—";
    if (totalProcesses) totalProcesses.textContent = "—";
    if (totalInquiries) totalInquiries.textContent = "—";
    if (totalOrders) totalOrders.textContent = "—";
}

function getTimestamp(value) {
    if (value?.toDate) return value.toDate().getTime();
    if (value instanceof Date) return value.getTime();
    return 0;
}

function renderRecentOrders(orders) {
    if (!recentOrders) return;

    recentOrders.replaceChildren();

    const latest = [...orders]
        .sort((a, b) =>
            (getTimestamp(b.createdAt) || 0) -
            (getTimestamp(a.createdAt) || 0)
        )
        .slice(0, 5);

    if (latest.length === 0) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");

        cell.colSpan = 3;
        cell.textContent = "No orders yet.";

        row.appendChild(cell);
        recentOrders.appendChild(row);
        return;
    }

    latest.forEach(order => {
        const row = document.createElement("tr");

        const numberCell = document.createElement("td");
        numberCell.textContent = order.orderNumber || order.id.slice(0, 8);

        const customerCell = document.createElement("td");

        const customerName = document.createElement("strong");
        customerName.textContent = order.customerName || "Unknown Customer";

        const total = document.createElement("small");
        total.textContent = "₱" + Number(order.total || 0).toLocaleString("en-PH", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        customerCell.append(customerName, total);

        const statusCell = document.createElement("td");
        const status = document.createElement("span");

        const key = String(order.status || "pending")
            .toLowerCase()
            .replace(/[^a-z]/g, "");

        status.textContent = key.charAt(0).toUpperCase() + key.slice(1);
        status.className = `status ${key}`;

        statusCell.appendChild(status);

        row.append(numberCell, customerCell, statusCell);
        recentOrders.appendChild(row);
    });
}

async function loadDashboardData() {
    const [
        productsSnapshot,
        processesSnapshot,
        inquiriesSnapshot,
        ordersSnapshot
    ] = await Promise.all([
        getDocs(collection(db, "products")),
        getDocs(collection(db, "processes")),
        getDocs(collection(db, "inquiries")),
        getDocs(collection(db, "orders"))
    ]);

    const products = productsSnapshot.docs.map(document => ({
        id: document.id,
        ...document.data()
    }));

    const inquiries = inquiriesSnapshot.docs.map(document => ({
        id: document.id,
        ...document.data()
    }));

    const orders = ordersSnapshot.docs.map(document => ({
        id: document.id,
        ...document.data()
    }));

    if (totalProducts) totalProducts.textContent = products.length;
    if (totalProcesses) totalProcesses.textContent = processesSnapshot.size;
    if (totalInquiries) totalInquiries.textContent = inquiries.length;
    if (totalOrders) totalOrders.textContent = orders.length;

    if (chartTotal) chartTotal.textContent = products.length;

    const categories = products.map(product =>
        String(product.category || "").toLowerCase()
    );

    const breads = categories.filter(category =>
        category.includes("bread")
    ).length;

    const muffins = categories.filter(category =>
        category.includes("muffin")
    ).length;

    const cookies = categories.filter(category =>
        category.includes("cookie")
    ).length;

    if (breadCount) breadCount.textContent = breads;
    if (muffinCount) muffinCount.textContent = muffins;
    if (cookieCount) cookieCount.textContent = cookies;

    inquiryCount = inquiries.length;

    pendingOrders = orders.filter(order =>
        String(order.status || "").toLowerCase() === "pending"
    ).length;

    renderRecentOrders(orders);
}

onAuthStateChanged(auth, async user => {
    if (!user) {
        window.location.replace("admin-login.html");
        return;
    }

    try {
        const adminRef = doc(db, "users", user.uid);
        const adminSnapshot = await getDoc(adminRef);

        if (!adminSnapshot.exists()) {
            await signOut(auth);
            window.location.replace("admin-login.html");
            return;
        }

        const adminData = adminSnapshot.data();

        if (adminData.role !== "admin" || adminData.status !== "active") {
            await signOut(auth);
            window.location.replace("admin-login.html");
            return;
        }

        setAdminProfile(adminData, user);

        await loadDashboardData();

    } catch (error) {
        console.error("Dashboard error:", error);
        showDashboardError(
            "Unable to load dashboard data. Check Firestore Security Rules and network connection."
        );
    }
});
