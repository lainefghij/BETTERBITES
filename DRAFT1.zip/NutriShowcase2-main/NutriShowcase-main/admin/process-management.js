
import { auth, db } from "../firebase/firebase.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

const $ = id => document.getElementById(id);

const elements = {
  productSelect: $("productSelect"),
  selectedProductCard: $("selectedProductCard"),
  otherProducts: $("otherProducts"),
  processGrid: $("processGrid"),
  processSubtitle: $("processSubtitle"),
  totalProducts: $("totalProducts"),
  totalSteps: $("totalSteps"),
  activeSteps: $("activeSteps"),
  search: $("stepSearch"),
  filter: $("statusFilter"),
  modal: $("stepModal"),
  form: $("stepForm"),
  modalTitle: $("modalTitle"),
  stepId: $("stepId"),
  title: $("stepTitle"),
  description: $("stepDescription"),
  status: $("stepStatus"),
  duration: $("stepDuration"),
  imageInput: $("stepImage"),
  imagePreviewWrap: $("imagePreviewWrap"),
  imagePreview: $("imagePreview"),
  toast: $("toast"),
  emptyState: $("emptyState")
};

let products = [];
let processes = [];
let selectedProductId = "";
let pendingImage = "";
let toastTimer;

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[char]));
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => elements.toast.classList.remove("show"), 2600);
}

function currentProduct() {
  return products.find(product => product.id === selectedProductId);
}

function currentSteps() {
    return processes
        .filter(step => String(step.productId).trim() === String(selectedProductId).trim())
        .sort((a, b) => Number(a.stepNumber || 0) - Number(b.stepNumber || 0));
}

async function verifyAdmin(user) {
  const userRef = doc(db, "users", user.uid);
  const userSnap = await getDoc(userRef);

  if (!userSnap.exists()) {
    await signOut(auth);
    window.location.href = "admin-login.html";
    return false;
  }

  const userData = userSnap.data();

  if (userData.role !== "admin" || userData.status !== "active") {
    await signOut(auth);
    window.location.href = "admin-login.html";
    return false;
  }

  return true;
}

async function loadProducts() {
  const snapshot = await getDocs(collection(db, "products"));

  products = snapshot.docs
    .map(document => ({
      id: document.id,
      ...document.data()
    }))
    .filter(product => product.status === "active");

  if (!products.length) {
    selectedProductId = "";
    renderAll();
    showToast("No active products found.");
    return;
  }

  if (!products.some(product => product.id === selectedProductId)) {
    selectedProductId = products[0].id;
  }

  await loadProcesses();
}

async function loadProcesses() {
  const snapshot = await getDocs(collection(db, "processes"));

  processes = snapshot.docs.map(document => ({
    id: document.id,
    ...document.data()
  }));

  renderAll();
}

function renderProductChoices() {
  if (!products.length) {
    elements.productSelect.innerHTML = "";
    elements.selectedProductCard.innerHTML = "<p>No active products available.</p>";
    elements.otherProducts.innerHTML = "";
    return;
  }

  elements.productSelect.innerHTML = products.map(product =>
    `<option value="${product.id}">${escapeHTML(product.productName)}</option>`
  ).join("");

  elements.productSelect.value = selectedProductId;

  const product = currentProduct();
  const steps = currentSteps();

  if (!product) return;

  elements.selectedProductCard.innerHTML = `
    <div class="selected-product-emoji">🍞</div>
    <div class="selected-product-info">
      <h3>${escapeHTML(product.productName)}</h3>
      <p>${escapeHTML(product.description || "")}</p>
      <span class="product-step-count">${steps.length} Production ${steps.length === 1 ? "Step" : "Steps"}</span>
    </div>
  `;

  elements.otherProducts.innerHTML = products
    .filter(item => item.id !== selectedProductId)
    .map(item => {
      const count = processes.filter(step => step.productId === item.id).length;

      return `
        <button class="other-product-card" type="button" data-product="${item.id}">
          <span class="other-product-emoji">🍞</span>
          <span>
            <strong>${escapeHTML(item.productName)}</strong>
            <small>${count} Production Steps</small>
          </span>
        </button>
      `;
    }).join("");

  elements.otherProducts.querySelectorAll("[data-product]").forEach(button => {
    button.addEventListener("click", () => selectProduct(button.dataset.product));
  });
}

function renderSummary() {
  elements.totalProducts.textContent = products.length;
  elements.totalSteps.textContent = processes.length;
  elements.activeSteps.textContent = processes.filter(step => step.status === "active").length;
}

function renderSteps() {
  const product = currentProduct();

  if (!product) {
    elements.processSubtitle.textContent = "No product selected";
    elements.processGrid.innerHTML = "";
    elements.emptyState.classList.remove("hidden");
    elements.processGrid.classList.add("hidden");
    return;
  }

  elements.processSubtitle.textContent = `Production steps for: ${product.productName}`;

  const queryText = elements.search.value.trim().toLowerCase();
  const filter = elements.filter.value;

  const visibleSteps = currentSteps().filter(step => {
    const matchesText = `${step.stepTitle} ${step.description}`.toLowerCase().includes(queryText);
    return matchesText && (filter === "all" || step.status === filter);
  });

  elements.processGrid.innerHTML = visibleSteps.map(step => `
    <article class="process-step-card" data-id="${step.id}">
      <div class="step-card-top">
        <span class="drag-handle">⠿</span>
        <span class="step-number">STEP ${String(step.stepNumber || 0).padStart(2, "0")}</span>
      </div>
      <div class="step-photo">
        ${step.processImage
          ? `<img src="${step.processImage}" alt="${escapeHTML(step.stepTitle)}" loading="lazy">`
          : "🍞"}
      </div>
      <div class="step-card-content">
        <h3>${escapeHTML(step.stepTitle)}</h3>
        <p class="step-description">${escapeHTML(step.description)}</p>
        <div class="step-meta">
          <span class="status-pill ${step.status}">${escapeHTML(step.status)}</span>
          <span class="step-duration">◷ ${escapeHTML(step.duration || "No duration")}</span>
        </div>
      </div>
      <div class="step-card-actions">
        <button class="step-action" type="button" data-edit="${step.id}">Edit</button>
        <button class="step-action delete" type="button" data-delete="${step.id}">Delete</button>
      </div>
    </article>
  `).join("");

  elements.emptyState.classList.toggle("hidden", visibleSteps.length !== 0);
  elements.processGrid.classList.toggle("hidden", visibleSteps.length === 0);

  elements.processGrid.querySelectorAll("[data-edit]").forEach(button => {
    button.addEventListener("click", () => openEdit(button.dataset.edit));
  });

  elements.processGrid.querySelectorAll("[data-delete]").forEach(button => {
    button.addEventListener("click", () => deleteStep(button.dataset.delete));
  });
}

function renderAll() {
  renderProductChoices();
  renderSummary();
  renderSteps();
}

function selectProduct(id) {
  if (!products.some(product => product.id === id)) return;

  selectedProductId = id;
  elements.search.value = "";
  elements.filter.value = "all";
  renderAll();
}

function openModal(step = null) {
  elements.form.reset();

  pendingImage = step?.processImage || "";
  elements.stepId.value = step?.id || "";
  elements.title.value = step?.stepTitle || "";
  elements.description.value = step?.description || "";
  elements.status.value = step?.status || "active";
  elements.duration.value = step?.duration || "";

  elements.modalTitle.textContent = step ? "Edit Process Step" : "Add Process Step";

  updateImagePreview();

  elements.modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";

  setTimeout(() => elements.title.focus(), 50);
}

function closeModal() {
  elements.modal.classList.add("hidden");
  document.body.style.overflow = "";
  pendingImage = "";
}

function openEdit(id) {
  const step = processes.find(item => item.id === id);

  if (step) openModal(step);
}

function updateImagePreview() {
  elements.imagePreviewWrap.classList.toggle("hidden", !pendingImage);

  if (pendingImage) {
    elements.imagePreview.src = pendingImage;
  } else {
    elements.imagePreview.removeAttribute("src");
  }
}

function compressImage(file) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      return reject(new Error("Please choose an image file."));
    }

    const reader = new FileReader();

    reader.onerror = () => reject(new Error("Unable to read image."));

    reader.onload = () => {
      const image = new Image();

      image.onerror = () => reject(new Error("Invalid image file."));

      image.onload = () => {
        const max = 800;
        const scale = Math.min(1, max / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");

        canvas.width = Math.round(image.width * scale);
        canvas.height = Math.round(image.height * scale);

        canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);

        resolve(canvas.toDataURL("image/jpeg", 0.65));
      };

      image.src = reader.result;
    };

    reader.readAsDataURL(file);
  });
}

async function saveStep(event) {
  event.preventDefault();

  const product = currentProduct();

  if (!product) {
    showToast("Please select a product first.");
    return;
  }

  const title = elements.title.value.trim();
  const description = elements.description.value.trim();

  if (!title || !description) return;

  const id = elements.stepId.value;
  const existingStep = processes.find(step => step.id === id);

  const stepData = {
    productId: selectedProductId,
    stepNumber: existingStep?.stepNumber || currentSteps().length + 1,
    stepTitle: title,
    description,
    processImage: pendingImage,
    duration: elements.duration.value.trim(),
    status: elements.status.value,
    updatedAt: serverTimestamp()
  };

  try {
    if (id) {
      await updateDoc(doc(db, "processes", id), stepData);
      showToast("Production step updated.");
    } else {
      stepData.createdAt = serverTimestamp();
      await addDoc(collection(db, "processes"), stepData);
      showToast("Production step added.");
    }

    closeModal();
    await loadProcesses();
  } catch (error) {
    console.error(error);
    showToast("Unable to save process step. Check Firestore rules.");
  }
}

async function deleteStep(id) {
  const step = processes.find(item => item.id === id);

  if (!step) return;

  if (!confirm(`Delete "${step.stepTitle}"? This action cannot be undone.`)) return;

  try {
    await deleteDoc(doc(db, "processes", id));
    showToast("Production step deleted.");
    await loadProcesses();
  } catch (error) {
    console.error(error);
    showToast("Unable to delete process step.");
  }
}

elements.productSelect.addEventListener("change", event => {
  selectProduct(event.target.value);
});

elements.search.addEventListener("input", renderSteps);
elements.filter.addEventListener("change", renderSteps);

$("addStepButton").addEventListener("click", () => openModal());
$("emptyAddButton").addEventListener("click", () => openModal());
$("closeModal").addEventListener("click", closeModal);
$("cancelModal").addEventListener("click", closeModal);

elements.modal.addEventListener("click", event => {
  if (event.target === elements.modal) closeModal();
});

document.addEventListener("keydown", event => {
  if (event.key === "Escape" && !elements.modal.classList.contains("hidden")) {
    closeModal();
  }
});

$("removeImageButton").addEventListener("click", () => {
  pendingImage = "";
  elements.imageInput.value = "";
  updateImagePreview();
});

elements.imageInput.addEventListener("change", async event => {
  const file = event.target.files?.[0];

  if (!file) return;

  try {
    pendingImage = await compressImage(file);
    updateImagePreview();
  } catch (error) {
    showToast(error.message || "Unable to process image.");
    event.target.value = "";
  }
});

elements.form.addEventListener("submit", saveStep);

$("menuToggle").addEventListener("click", () => {
  $("sidebar").classList.toggle("open");
  $("sidebarOverlay").classList.toggle("show");
});

$("sidebarOverlay").addEventListener("click", () => {
  $("sidebar").classList.remove("open");
  $("sidebarOverlay").classList.remove("show");
});

$("profileButton").addEventListener("click", event => {
  event.stopPropagation();
  const isOpen = $("profileDropdown").classList.toggle("show");
  $("profileButton").setAttribute("aria-expanded", String(isOpen));
});

document.addEventListener("click", event => {
  if (!event.target.closest(".profile-container")) {
    $("profileDropdown").classList.remove("show");
    $("profileButton").setAttribute("aria-expanded", "false");
  }
});

async function logoutAdmin(event) {
  event?.preventDefault();
  if (!confirm("Are you sure you want to log out?")) return;
  try {
    await signOut(auth);
  } finally {
    location.href = "admin-login.html";
  }
}

$("logoutButton").addEventListener("click", logoutAdmin);
$("dropdownLogout").addEventListener("click", logoutAdmin);

$("currentYear").textContent = new Date().getFullYear();

onAuthStateChanged(auth, async user => {
  if (!user) {
    window.location.href = "admin-login.html";
    return;
  }

  try {
    const allowed = await verifyAdmin(user);

    if (allowed) {
      await loadProducts();
    }
  } catch (error) {
    console.error(error);
    showToast("Unable to load Firebase data.");
  }
});
