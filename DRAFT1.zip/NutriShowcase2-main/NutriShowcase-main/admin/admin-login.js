import {
    signInWithEmailAndPassword,
    sendPasswordResetEmail,
    setPersistence,
    browserLocalPersistence,
    browserSessionPersistence,
    signOut
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

import { auth, db } from "../firebase/firebase.js";

const loginForm = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");

const passwordToggle = document.getElementById("passwordToggle");
const eyeIcon = document.getElementById("eyeIcon");

const formMessage = document.getElementById("formMessage");
const forgotLink = document.getElementById("forgotLink");
const rememberMeInput = document.getElementById("rememberMe");

function showMessage(message, type) {
    formMessage.textContent = message;
    formMessage.className = "form-message " + type;
}

function clearMessage() {
    formMessage.textContent = "";
    formMessage.className = "form-message";
}

// SHOW AND HIDE PASSWORD
passwordToggle?.addEventListener("click", function () {
    const showPassword = passwordInput.type === "password";

    passwordInput.type = showPassword ? "text" : "password";

    passwordToggle.setAttribute("aria-pressed", String(showPassword));
    passwordToggle.setAttribute(
        "aria-label",
        showPassword ? "Hide password" : "Show password"
    );

    if (eyeIcon) {
        eyeIcon.innerHTML = showPassword
            ? `
                <path d="M3 3L21 21"/>
                <path d="M10.6 5.7A10.9 10.9 0 0 1 12 5.5C18.5 5.5 22 12 22 12S20.8 14.3 18.7 16"/>
                <path d="M6.2 6.8C3.5 8.6 2 12 2 12S5.5 18.5 12 18.5c1.4 0 2.7-.3 3.8-.8"/>
                <path d="M9.9 9.9A3 3 0 0 0 14.1 14.1"/>
            `
            : `
                <path d="M2 12S5.5 5.5 12 5.5S22 12 22 12S18.5 18.5 12 18.5S2 12 2 12Z"/>
                <circle cx="12" cy="12" r="3"/>
            `;
    }
});

// CLEAR MESSAGE WHEN TYPING
emailInput.addEventListener("input", clearMessage);
passwordInput.addEventListener("input", clearMessage);

// FORGOT PASSWORD
forgotLink?.addEventListener("click", async function (event) {
    event.preventDefault();
    clearMessage();

    const email = emailInput.value.trim();

    if (!email || !emailInput.checkValidity()) {
        showMessage("Please enter a valid email address first.", "error");
        emailInput.focus();
        return;
    }

    try {
        await sendPasswordResetEmail(auth, email);
        showMessage("Password reset email sent. Please check your inbox.", "success");
    } catch (error) {
        console.error("Password reset error:", error);
        showMessage("Unable to send password reset email. Please check your email address.", "error");
    }
});

// ADMIN LOGIN
loginForm.addEventListener("submit", async function (event) {
    event.preventDefault();
    clearMessage();

    const email = emailInput.value.trim();
    const password = passwordInput.value;

    if (!email || !password) {
        showMessage("Please enter both your email address and password.", "error");
        return;
    }

    if (!emailInput.checkValidity()) {
        showMessage("Please enter a valid email address.", "error");
        emailInput.focus();
        return;
    }

    const submitButton = loginForm.querySelector('button[type="submit"]');

    try {
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent = "Signing in...";
        }

        const persistence = rememberMeInput?.checked
            ? browserLocalPersistence
            : browserSessionPersistence;

        await setPersistence(auth, persistence);

        const userCredential = await signInWithEmailAndPassword(
            auth,
            email,
            password
        );

        const user = userCredential.user;

        const adminRef = doc(db, "users", user.uid);
        const adminSnapshot = await getDoc(adminRef);

        if (!adminSnapshot.exists()) {
            await signOut(auth);
            showMessage("Access denied. Admin profile was not found.", "error");
            return;
        }

        const adminData = adminSnapshot.data();

        if (adminData.role !== "admin" || adminData.status !== "active") {
            await signOut(auth);
            showMessage("Access denied. This account is not an active administrator.", "error");
            return;
        }

        showMessage("Login successful! Redirecting...", "success");

        window.location.href = "admin-dashboard.html";

    } catch (error) {
        console.error("Admin login error:", error);

        let message = "Login failed. Please try again.";

        if (
            error.code === "auth/invalid-credential" ||
            error.code === "auth/user-not-found" ||
            error.code === "auth/wrong-password"
        ) {
            message = "Incorrect email or password.";
        } else if (error.code === "auth/too-many-requests") {
            message = "Too many attempts. Please try again later.";
        } else if (error.code === "auth/network-request-failed") {
            message = "Network error. Please check your internet connection.";
        } else if (error.code === "permission-denied") {
            message = "Access denied by Firestore security rules.";
        }

        showMessage(message, "error");

    } finally {
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.textContent = "Sign In";
        }
    }
});
