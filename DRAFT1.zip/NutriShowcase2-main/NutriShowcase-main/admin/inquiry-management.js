
import { auth, db } from "../firebase/firebase.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import {
    collection,
    doc,
    getDoc,
    getDocs,
    updateDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

document.addEventListener("DOMContentLoaded", () => {
    let inquiries = [];
    let selectedInquiryId = null;

    const tableBody = document.getElementById("inquiryTableBody");
    const searchInput = document.getElementById("searchInput");
    const statusFilter = document.getElementById("statusFilter");
    const sortFilter = document.getElementById("sortFilter");
    const modal = document.getElementById("inquiryModal");
    const sidebar = document.getElementById("sidebar");
    const sidebarOverlay = document.getElementById("sidebarOverlay");

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, character => {
            const entities = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            };
            return entities[character];
        });
    }

    function formatDate(value) {
        if (!value) return "—";

        let date;

        if (value.toDate) {
            date = value.toDate();
        } else if (value instanceof Date) {
            date = value;
        } else {
            date = new Date(value);
        }

        if (Number.isNaN(date.getTime())) return "—";

        return date.toLocaleDateString("en-PH", {
            month: "short",
            day: "numeric",
            year: "numeric"
        });
    }

    function getDateValue(value) {
        if (!value) return 0;

        if (value.toDate) return value.toDate().getTime();

        const date = new Date(value);
        return Number.isNaN(date.getTime()) ? 0 : date.getTime();
    }

    function normalizeStatus(status) {
        const value = String(status || "").toLowerCase();

        if (value === "quoted") return "Quoted";
        if (value === "confirmed") return "Confirmed";

        return "New Inquiry";
    }

    function firestoreStatus(status) {
        if (status === "Quoted") return "quoted";
        if (status === "Confirmed") return "confirmed";

        return "new";
    }

    function getStatusClass(status) {
        if (status === "Quoted") return "quoted";
        if (status === "Confirmed") return "confirmed";

        return "new-inquiry";
    }

    async function verifyAdmin(user) {
        const userRef = doc(db, "users", user.uid);
        const userSnapshot = await getDoc(userRef);

        if (!userSnapshot.exists()) {
            throw new Error("Admin profile not found.");
        }

        const profile = userSnapshot.data();

        if (profile.role !== "admin" || profile.status !== "active") {
            throw new Error("You do not have permission to access this page.");
        }

        const profileName = document.querySelector(".profile-name");

        if (profileName) {
            profileName.textContent = profile.fullName || "Admin";
        }
    }

    async function loadInquiries() {
        try {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6">Loading inquiries...</td>
                </tr>
            `;

            const [inquirySnapshot, productSnapshot] = await Promise.all([
                getDocs(collection(db, "inquiries")),
                getDocs(collection(db, "products"))
            ]);

            const products = {};

            productSnapshot.forEach(productDoc => {
                const product = productDoc.data();
                products[productDoc.id] = product.productName || "Unknown Product";
            });

            inquiries = inquirySnapshot.docs.map(inquiryDoc => {
                const data = inquiryDoc.data();

                const productName =
                    products[data.productId] ||
                    data.productName ||
                    "Product not specified";

                return {
                    id: inquiryDoc.id,
                    name: data.customerName || "—",
                    email: data.email || "—",
                    phone: data.contactNumber || "—",
                    companyName: data.companyName || "",
                    inquiryType: data.inquiryType || "General Inquiry",
                    product: productName,
                    quantity: data.quantity ? `${data.quantity}` : "—",
                    date: data.createdAt || null,
                    status: normalizeStatus(data.status),
                    message: data.message || "No message provided.",
                    response: data.response || data.adminResponse || ""
                };
            });

            renderInquiries();
        } catch (error) {
            console.error("Error loading inquiries:", error);

            tableBody.innerHTML = `
                <tr>
                    <td colspan="6">Unable to load inquiries. Check your Firebase connection and permissions.</td>
                </tr>
            `;

            alert(error.message || "Failed to load inquiries.");
        }
    }

    function updateSummary() {
        document.getElementById("totalInquiries").textContent = inquiries.length;

        document.getElementById("newInquiries").textContent =
            inquiries.filter(item => item.status === "New Inquiry").length;

        document.getElementById("quotedInquiries").textContent =
            inquiries.filter(item => item.status === "Quoted").length;

        document.getElementById("confirmedInquiries").textContent =
            inquiries.filter(item => item.status === "Confirmed").length;
    }

    function renderInquiries() {
        const searchTerm = searchInput.value.toLowerCase().trim();
        const selectedStatus = statusFilter.value;
        const sortOrder = sortFilter.value;

        let filtered = inquiries.filter(item => {
            const searchableText = [
                item.id,
                item.name,
                item.email,
                item.phone,
                item.product,
                item.companyName,
                item.inquiryType
            ].join(" ").toLowerCase();

            const matchesSearch = searchableText.includes(searchTerm);

            const matchesStatus =
                selectedStatus === "all" || item.status === selectedStatus;

            return matchesSearch && matchesStatus;
        });

        filtered.sort((a, b) => {
            const dateA = getDateValue(a.date);
            const dateB = getDateValue(b.date);

            return sortOrder === "newest"
                ? dateB - dateA
                : dateA - dateB;
        });

        tableBody.innerHTML = "";

        filtered.forEach(item => {
            const row = document.createElement("tr");

            row.innerHTML = `
                <td>
                    <span class="inquiry-number">${escapeHTML(item.id)}</span>
                </td>
                <td>
                    <div class="customer-cell">
                        <strong>${escapeHTML(item.name)}</strong>
                        <small>${escapeHTML(item.email)}</small>
                    </div>
                </td>
                <td>${escapeHTML(item.product)}</td>
                <td>${formatDate(item.date)}</td>
                <td>
                    <span class="status ${getStatusClass(item.status)}">
                        ${escapeHTML(item.status)}
                    </span>
                </td>
                <td>
                    <button class="view-button" data-id="${escapeHTML(item.id)}">
                        View Details
                    </button>
                </td>
            `;

            tableBody.appendChild(row);
        });

        document.getElementById("emptyState").hidden = filtered.length !== 0;

        document.getElementById("resultCount").textContent =
            `Showing ${filtered.length} of ${inquiries.length} inquiries`;

        updateSummary();
    }

    function openInquiry(id) {
        const inquiry = inquiries.find(item => item.id === id);

        if (!inquiry) return;

        selectedInquiryId = id;

        document.getElementById("detailInquiryNumber").textContent = inquiry.id;
        document.getElementById("detailName").textContent = inquiry.name;
        document.getElementById("detailEmail").textContent = inquiry.email;
        document.getElementById("detailPhone").textContent = inquiry.phone;
        document.getElementById("detailDate").textContent = formatDate(inquiry.date);
        document.getElementById("detailProduct").textContent = inquiry.product;
        document.getElementById("detailQuantity").textContent = inquiry.quantity;
        document.getElementById("detailMessage").textContent = inquiry.message;

        document.getElementById("adminResponse").value = inquiry.response || "";
        document.getElementById("detailStatus").value = inquiry.status;

        modal.classList.add("show");
        document.body.style.overflow = "hidden";
    }

    function closeModal() {
        modal.classList.remove("show");
        document.body.style.overflow = "";
        selectedInquiryId = null;
    }

    async function saveInquiryChanges() {
        if (!selectedInquiryId) return;

        const response = document.getElementById("adminResponse").value.trim();
        const status = document.getElementById("detailStatus").value;

        try {
            const inquiryRef = doc(db, "inquiries", selectedInquiryId);

            await updateDoc(inquiryRef, {
                response: response,
                status: firestoreStatus(status),
                updatedAt: serverTimestamp()
            });

            const inquiry = inquiries.find(item => item.id === selectedInquiryId);

            if (inquiry) {
                inquiry.response = response;
                inquiry.status = status;
            }

            renderInquiries();
            closeModal();

            alert("Inquiry details updated successfully in Firebase.");
        } catch (error) {
            console.error("Error updating inquiry:", error);
            alert(error.message || "Unable to update inquiry.");
        }
    }

    function exportCSV() {
        if (inquiries.length === 0) {
            alert("There are no inquiries to export.");
            return;
        }

        const headers = [
            "Inquiry Number",
            "Customer Name",
            "Email",
            "Phone",
            "Product",
            "Quantity",
            "Date",
            "Status",
            "Customer Message",
            "Admin Response"
        ];

        const rows = inquiries.map(item => [
            item.id,
            item.name,
            item.email,
            item.phone,
            item.product,
            item.quantity,
            formatDate(item.date),
            item.status,
            item.message,
            item.response
        ]);

        const csvContent = [headers, ...rows]
            .map(row => row.map(value =>
                `"${String(value ?? "").replace(/"/g, '""')}"`
            ).join(","))
            .join("\n");

        const blob = new Blob(["\uFEFF" + csvContent], {
            type: "text/csv;charset=utf-8;"
        });

        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");

        link.href = url;
        link.download = "BETTERBITES-Inquiries.csv";

        document.body.appendChild(link);
        link.click();
        link.remove();

        URL.revokeObjectURL(url);
    }

    tableBody.addEventListener("click", event => {
        const button = event.target.closest(".view-button");

        if (!button) return;

        openInquiry(button.dataset.id);
    });

    searchInput.addEventListener("input", renderInquiries);
    statusFilter.addEventListener("change", renderInquiries);
    sortFilter.addEventListener("change", renderInquiries);

    document.getElementById("closeModal").addEventListener("click", closeModal);
    document.getElementById("cancelModal").addEventListener("click", closeModal);
    document.getElementById("saveInquiry").addEventListener("click", saveInquiryChanges);

    modal.addEventListener("click", event => {
        if (event.target === modal) closeModal();
    });

    document.addEventListener("keydown", event => {
        if (event.key === "Escape") {
            closeModal();
            closeSidebar();
        }
    });

    const menuToggle = document.getElementById("menuToggle");

    function closeSidebar() {
        sidebar.classList.remove("open");
        sidebarOverlay.classList.remove("show");
    }

    menuToggle.addEventListener("click", () => {
        sidebar.classList.toggle("open");
        sidebarOverlay.classList.toggle("show");
    });

    sidebarOverlay.addEventListener("click", closeSidebar);

    const profileButton = document.getElementById("profileButton");
    const profileDropdown = document.getElementById("profileDropdown");

    profileButton.addEventListener("click", event => {
        event.stopPropagation();
        profileDropdown.classList.toggle("show");
    });

    document.addEventListener("click", event => {
        if (!event.target.closest(".profile-container")) {
            profileDropdown.classList.remove("show");
        }
    });

    async function logout() {
        const confirmed = confirm("Are you sure you want to log out?");

        if (!confirmed) return;

        try {
            await signOut(auth);
            window.location.href = "admin-login.html";
        } catch (error) {
            alert("Unable to log out: " + error.message);
        }
    }

    document.getElementById("logoutButton").addEventListener("click", event => {
        event.preventDefault();
        logout();
    });

    document.getElementById("dropdownLogout").addEventListener("click", logout);
    document.getElementById("exportButton").addEventListener("click", exportCSV);

    onAuthStateChanged(auth, async user => {
        if (!user) {
            window.location.href = "admin-login.html";
            return;
        }

        try {
            await verifyAdmin(user);
            await loadInquiries();
        } catch (error) {
            console.error("Admin verification failed:", error);
            alert(error.message || "Admin verification failed.");
            await signOut(auth);
            window.location.href = "admin-login.html";
        }
    });
});
