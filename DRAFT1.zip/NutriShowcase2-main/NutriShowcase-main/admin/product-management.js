
import { auth, db } from "../firebase/firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";

import {
    collection,
    doc,
    getDoc,
    getDocs,
    addDoc,
    updateDoc,
    deleteDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

document.addEventListener("DOMContentLoaded", () => {
    const $ = id => document.getElementById(id);
    const LOW_STOCK_LIMIT = 5;
    const PAGE_SIZE = 6;

    const form = $("productForm");
    const modal = $("productModal");
    const imageInput = $("productImageFile");
    const imagePreview = $("imagePreview");
    const uploadPlaceholder = $("uploadPlaceholder");
    const removeImageButton = $("removeImageButton");
    const saveButton = $("saveProductButton");

    let products = [];
    let currentPage = 1;
    let selectedImage = "";
    let currentUser = null;
    let toastTimer;

    function showToast(message) {
        const toast = $("toast");
        toast.textContent = message;
        toast.classList.add("show");
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
    }

    function getStockStatus(product) {
        const quantity = Number(product.stock) || 0;

        if (!product.available || quantity <= 0) return "Out of Stock";
        if (quantity <= LOW_STOCK_LIMIT) return "Low Stock";

        return "In Stock";
    }

    function updateSummary() {
        $("totalProducts").textContent = products.length;
        $("inStockProducts").textContent = products.filter(p => getStockStatus(p) === "In Stock").length;
        $("lowStockProducts").textContent = products.filter(p => getStockStatus(p) === "Low Stock").length;
        $("outOfStockProducts").textContent = products.filter(p => getStockStatus(p) === "Out of Stock").length;
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, char => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[char]);
    }

    function formatPrice(value) {
        return Number(value || 0).toLocaleString("en-PH", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function renderProducts() {
        const term = $("productSearch").value.trim().toLowerCase();
        const filter = $("stockFilter").value;

        const filtered = products.filter(product => {
            const matchesText =
                `${product.name} ${product.description}`.toLowerCase().includes(term);

            return matchesText &&
                (filter === "all" || getStockStatus(product) === filter);
        });

        const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
        currentPage = Math.min(currentPage, totalPages);

        const start = (currentPage - 1) * PAGE_SIZE;
        const shown = filtered.slice(start, start + PAGE_SIZE);
        const body = $("productTableBody");

        body.innerHTML = "";

        shown.forEach(product => {
            const status = getStockStatus(product);
            const row = document.createElement("tr");

            const imageMarkup = product.image
                ? `<img src="${escapeHTML(product.image)}" class="product-image-cell" alt="${escapeHTML(product.name)}" loading="lazy">`
                : `<div class="no-image" aria-label="No product image">▣</div>`;

            const statusClass =
                status === "In Stock" ? "in-stock" :
                status === "Low Stock" ? "low-stock" :
                "out-stock";

            row.innerHTML = `
                <td>${imageMarkup}</td>
                <td><strong class="product-name">${escapeHTML(product.name)}</strong></td>
                <td><span class="product-description">${escapeHTML(product.description)}</span></td>
                <td><strong class="price">₱${formatPrice(product.price)}</strong></td>
                <td>${Number(product.stock) || 0}</td>
                <td><span class="stock-badge ${statusClass}">${status}</span></td>
                <td>
                    <div class="action-buttons">
                        <button type="button" class="edit-button" data-action="edit" data-id="${escapeHTML(product.id)}">Edit</button>
                        <button type="button" class="delete-button" data-action="delete" data-id="${escapeHTML(product.id)}">Delete</button>
                    </div>
                </td>
            `;

            body.appendChild(row);
        });

        $("emptyState").hidden = filtered.length !== 0;
        $("seedButton").hidden = products.length !== 0;

        const first = filtered.length ? start + 1 : 0;
        const last = Math.min(start + PAGE_SIZE, filtered.length);

        $("paginationInfo").textContent =
            `Showing ${first}–${last} of ${filtered.length} products`;

        $("currentPage").textContent = currentPage;
        $("previousPage").disabled = currentPage <= 1;
        $("nextPage").disabled = currentPage >= totalPages;

        updateSummary();
    }

    function showImage(data) {
        selectedImage = data || "";

        if (selectedImage) {
            imagePreview.src = selectedImage;
            imagePreview.hidden = false;
            uploadPlaceholder.hidden = true;
            removeImageButton.hidden = false;
        } else {
            imagePreview.removeAttribute("src");
            imagePreview.hidden = true;
            uploadPlaceholder.hidden = false;
            removeImageButton.hidden = true;
        }
    }

    function compressImage(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onerror = () => reject(new Error("Unable to read image."));

            reader.onload = event => {
                const image = new Image();

                image.onerror = () => reject(new Error("Invalid image file."));

                image.onload = () => {
                    const maxSide = 500;
                    const scale = Math.min(
                        1,
                        maxSide / Math.max(image.width, image.height)
                    );

                    const canvas = document.createElement("canvas");
                    canvas.width = Math.max(1, Math.round(image.width * scale));
                    canvas.height = Math.max(1, Math.round(image.height * scale));

                    const context = canvas.getContext("2d");

                    context.fillStyle = "#FFFFFF";
                    context.fillRect(0, 0, canvas.width, canvas.height);
                    context.drawImage(image, 0, 0, canvas.width, canvas.height);

                    const compressed = canvas.toDataURL("image/jpeg", 0.45);

                    if (compressed.length > 700000) {
                        reject(new Error("Image is too large after compression."));
                        return;
                    }

                    resolve(compressed);
                };

                image.src = event.target.result;
            };

            reader.readAsDataURL(file);
        });
    }

    imageInput.addEventListener("change", async () => {
        const file = imageInput.files?.[0];

        if (!file) return;

        const validTypes = ["image/jpeg", "image/png", "image/webp"];

        if (!validTypes.includes(file.type)) {
            showToast("Choose a JPG, PNG, or WEBP image.");
            imageInput.value = "";
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            showToast("Photo must be 5 MB or smaller.");
            imageInput.value = "";
            return;
        }

        try {
            const compressed = await compressImage(file);
            showImage(compressed);
            showToast("Photo ready. Save the product to keep it.");
        } catch (error) {
            console.error("Image error:", error);
            showToast(error.message || "Unable to process this photo.");
        }
    });

    removeImageButton.addEventListener("click", () => {
        imageInput.value = "";
        showImage("");
    });

    function openModal() {
        modal.classList.add("show");
        modal.setAttribute("aria-hidden", "false");
        document.body.style.overflow = "hidden";
        setTimeout(() => $("productName").focus(), 50);
    }

    function closeModal() {
        modal.classList.remove("show");
        modal.setAttribute("aria-hidden", "true");
        document.body.style.overflow = "";
        form.reset();
        $("productId").value = "";
        $("modalTitle").textContent = "Add Product";
        saveButton.disabled = false;
        saveButton.textContent = "Save Product";
        imageInput.value = "";
        showImage("");
    }

    function openAddProduct() {
        form.reset();
        $("productCategory").value = "Bread";
        $("productId").value = "";
        $("modalTitle").textContent = "Add Product";
        imageInput.value = "";
        showImage("");
        openModal();
    }

    function editProduct(id) {
        const product = products.find(item => item.id === id);

        if (!product) return;

        $("productId").value = product.id;
        $("productName").value = product.name || "";
        $("productDescription").value = product.description || "";
        $("productPrice").value = product.price ?? "";
        $("stockQuantity").value = product.stock ?? 0;
        $("productBadges").value = Array.isArray(product.badges)
            ? product.badges.join(", ")
            : "";

        $("productAvailable").checked = product.available !== false;
        $("productCategory").value = product.category || "Bread";
        $("modalTitle").textContent = "Edit Product";

        imageInput.value = "";
        showImage(product.image || "");

        openModal();
    }

    async function saveProduct(event) {
        event.preventDefault();

        if (!form.reportValidity()) return;

        const id = $("productId").value;
        const name = $("productName").value.trim();
        const description = $("productDescription").value.trim();
        const price = Number($("productPrice").value);
        const stock = Number($("stockQuantity").value);
        const available = $("productAvailable").checked;

        const badges = $("productBadges").value
            .split(",")
            .map(item => item.trim())
            .filter(Boolean);

        if (
            !name ||
            !description ||
            !Number.isFinite(price) ||
            price < 0 ||
            !Number.isInteger(stock) ||
            stock < 0
        ) {
            showToast("Please check the required product information.");
            return;
        }

        const oldProduct = products.find(item => item.id === id);

        const productData = {
            productName: name,
            description,
            price,
            stock,
            productImage: selectedImage || oldProduct?.image || "",
            nutritionBadges: badges,
            category: $("productCategory").value,
            availability: available ? "available" : "unavailable",
            status: "active",
            updatedAt: serverTimestamp()
        };

        saveButton.disabled = true;
        saveButton.textContent = "Saving...";

        try {
            if (oldProduct) {
                await updateDoc(doc(db, "products", id), productData);
                showToast("Product updated successfully.");
            } else {
                productData.ingredients = [];
                productData.createdAt = serverTimestamp();

                await addDoc(collection(db, "products"), productData);
                showToast("Product added successfully.");
            }

            closeModal();
            currentPage = 1;
            await loadProducts();

        } catch (error) {
            console.error("Product saving error:", error);

            if (error.code === "permission-denied") {
                showToast("Permission denied. Check Firestore Rules.");
            } else {
                showToast("Unable to save product. Please try again.");
            }
        } finally {
            saveButton.disabled = false;
            saveButton.textContent = "Save Product";
        }
    }

    async function deleteProduct(id) {
        const product = products.find(item => item.id === id);

        if (!product || !confirm(`Delete ${product.name}?`)) return;

        try {
            await deleteDoc(doc(db, "products", id));

            showToast("Product deleted successfully.");
            await loadProducts();

        } catch (error) {
            console.error("Product deletion error:", error);
            showToast("Unable to delete product. Check Firestore Rules.");
        }
    }

    async function loadProducts() {
        try {
            const snapshot = await getDocs(collection(db, "products"));

            products = snapshot.docs.map(document => {
                const data = document.data();

                return {
                    id: document.id,
                    name: data.productName || "",
                    description: data.description || "",
                    price: Number(data.price) || 0,
                    stock: Number(data.stock) || 0,
                    image: data.productImage || "",
                    badges: data.nutritionBadges || [],
                    available:
                        data.availability !== "unavailable" &&
                        data.status !== "inactive",
                    category: data.category || "Bread"
                };
            });

            renderProducts();

        } catch (error) {
            console.error("Product loading error:", error);

            if (error.code === "permission-denied") {
                showToast("Unable to read products. Check Firestore Rules.");
            } else {
                showToast("Unable to load products from Firebase.");
            }
        }
    }


    const SAMPLE_PRODUCTS = [
        { productName: "Whole Wheat Pandesal", description: "Soft, fluffy pandesal made with whole wheat flour.", price: 35, stock: 60, category: "Bread", nutritionBadges: ["High Protein"] },
        { productName: "Banana Bread", description: "Moist banana loaf, lightly sweetened.", price: 70, stock: 25, category: "Bread", nutritionBadges: ["Iron Fortified"] },
        { productName: "Blueberry Muffins", description: "Muffins packed with blueberries.", price: 55, stock: 40, category: "Muffin", nutritionBadges: [] },
        { productName: "Malunggay Cheese Rolls", description: "Cheesy rolls with malunggay for extra iron.", price: 40, stock: 30, category: "Bread", nutritionBadges: ["Iron Fortified"] },
        { productName: "Oat Cookies", description: "Chewy oat cookies, a wholesome snack.", price: 15, stock: 100, category: "Cookie", nutritionBadges: ["High Protein"] },
        { productName: "Carrot Muffins", description: "Carrot muffins rich in vitamin A.", price: 50, stock: 35, category: "Muffin", nutritionBadges: ["Vitamin A Enriched"] }
    ];

    $("seedButton").addEventListener("click", async () => {
        if (!confirm("Add 6 sample products to your database? You can edit or delete them later.")) return;

        try {
            for (const product of SAMPLE_PRODUCTS) {
                await addDoc(collection(db, "products"), {
                    ...product,
                    productImage: "",
                    ingredients: [],
                    availability: "available",
                    status: "active",
                    createdAt: serverTimestamp(),
                    updatedAt: serverTimestamp()
                });
            }
            showToast("Sample products added.");
            await loadProducts();
        } catch (error) {
            console.error("Seed error:", error);
            showToast("Unable to add sample products. Check Firestore Rules.");
        }
    });

    $("addProductButton").addEventListener("click", openAddProduct);
    form.addEventListener("submit", saveProduct);

    $("productTableBody").addEventListener("click", event => {
        const button = event.target.closest("button[data-action]");

        if (!button) return;

        const id = button.dataset.id;

        if (button.dataset.action === "edit") {
            editProduct(id);
        }

        if (button.dataset.action === "delete") {
            deleteProduct(id);
        }
    });

    $("productSearch").addEventListener("input", () => {
        currentPage = 1;
        renderProducts();
    });

    $("stockFilter").addEventListener("change", () => {
        currentPage = 1;
        renderProducts();
    });

    $("previousPage").addEventListener("click", () => {
        if (currentPage > 1) {
            currentPage--;
            renderProducts();
        }
    });

    $("nextPage").addEventListener("click", () => {
        currentPage++;
        renderProducts();
    });

    $("closeModal").addEventListener("click", closeModal);
    $("cancelModal").addEventListener("click", closeModal);

    modal.addEventListener("click", event => {
        if (event.target === modal) closeModal();
    });

    const sidebar = $("sidebar");
    const overlay = $("sidebarOverlay");

    function closeSidebar() {
        sidebar.classList.remove("open");
        overlay.classList.remove("show");
    }

    $("menuToggle").addEventListener("click", () => {
        sidebar.classList.toggle("open");
        overlay.classList.toggle("show");
    });

    overlay.addEventListener("click", closeSidebar);

    document.addEventListener("keydown", event => {
        if (event.key === "Escape") {
            closeModal();
            closeSidebar();
        }
    });

    $("profileButton").addEventListener("click", event => {
        event.stopPropagation();
        $("profileDropdown").classList.toggle("show");
    });

    document.addEventListener("click", event => {
        if (!event.target.closest(".profile-container")) {
            $("profileDropdown").classList.remove("show");
        }
    });

    $("notificationButton").addEventListener("click", () => {
        showToast(`${products.length} products are currently listed.`);
    });

    async function logout(event) {
        event?.preventDefault();

        if (!confirm("Are you sure you want to log out?")) return;

        try {
            await signOut(auth);
            window.location.replace("admin-login.html");
        } catch (error) {
            console.error("Logout error:", error);
            showToast("Unable to log out. Please try again.");
        }
    }

    $("logoutButton").addEventListener("click", logout);
    $("dropdownLogout").addEventListener("click", logout);

    onAuthStateChanged(auth, async user => {
        if (!user) {
            window.location.replace("admin-login.html");
            return;
        }

        try {
            const adminSnapshot = await getDoc(doc(db, "users", user.uid));

            if (!adminSnapshot.exists()) {
                await signOut(auth);
                window.location.replace("admin-login.html");
                return;
            }

            const adminData = adminSnapshot.data();

            if (adminData.role !== "admin" || adminData.status !== "active") {
                await signOut(auth);
                window.location.replace("admin-login.html");
                return;
            }

            currentUser = user;

            const adminName = adminData.fullName || "Admin";

            $("profileName").textContent = adminName;
            $("profileButton").querySelector(".profile-avatar").textContent =
                adminName.charAt(0).toUpperCase();

            await loadProducts();

        } catch (error) {
            console.error("Admin verification error:", error);
            showToast("Unable to verify admin access.");
        }
    });
});
