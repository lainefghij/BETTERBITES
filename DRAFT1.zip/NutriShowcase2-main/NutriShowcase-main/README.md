# BETTERBITES – Online Ordering System

Customers browse products, add to cart, check out (pickup or delivery) and track their orders.
Admins manage products, orders, process steps and bulk inquiries. Everything runs on Firebase
(Authentication + Firestore) with plain HTML/CSS/JS – no build step.

## 1. One-time Firebase setup (project `betterbites-32937`)

1. **Authentication** → *Sign-in method* → enable **Email/Password** (and **Google** if you want Google login).
   *Settings → Authorized domains*: add the domain you host on (`localhost` is allowed by default).
2. **Firestore Database** → *Create database* (production mode, pick a nearby region such as `asia-southeast1`).
3. **Publish the security rules** – either:
   - paste `firebase/firestore.rules` into *Firestore → Rules* and click **Publish**, or
   - run `firebase deploy --only firestore` (needs the Firebase CLI; `firebase.json` and `.firebaserc` are included).
4. **Create your first admin** (admins can only be created from the console, on purpose):
   1. *Authentication → Users → Add user* (email + password). Copy the user's **UID**.
   2. *Firestore → Start collection* `users` → Document ID = **that UID**, with fields  
      `fullName` (string), `email` (string), `role` = `admin` (string), `status` = `active` (string).
5. Open `admin/admin-login.html`, sign in, go to **Products** and click **Add sample products** (or add your own).
6. Edit `public/config.js` – delivery fee, free-delivery threshold, GCash number, etc.

> If your Firebase web config ever changes, edit `firebase/firebase.js`.

## 2. Run it

ES modules do not work from `file://`, so serve the folder:

```
npx serve .          # then open http://localhost:3000
# or
firebase deploy --only hosting
```

## 3. How it works

| Area | Pages |
|------|-------|
| Customer | `public/index.html`, `products.html`, `cart.html`, `checkout.html`, `my-orders.html`, `login.html`, `signup.html`, `forgot-password.html`, `inquiry.html` (bulk/custom quote), `process.html`, `about.html` |
| Admin | `admin/admin-login.html`, `admin-dashboard.html`, `orders-management.html`, `product-management.html`, `process-management.html`, `inquiry-management.html` |

**Order flow:** cart (browser storage) → checkout (login required) → one Firestore *transaction* re-checks stock,
lowers stock and creates the order → admin sees it live on **Orders** and moves it
`Pending → Confirmed → Preparing → Ready/Out for delivery → Completed` (or `Cancelled`, which returns stock).
Customers see status changes live on **My Orders**.

**Collections:** `users`, `products`, `orders`, `inquiries`, `processes`.

## 4. Known limits (be aware)

- **No online payment gateway.** Customers pay cash or via GCash manually; the admin marks the order *Paid*.
- Stock is protected by Firestore rules (a customer may only *lower* a stock number, never below 0), but prices/totals
  are calculated in the browser. For stricter protection move order creation to a Cloud Function (needs the Blaze plan).
- No automatic emails/SMS. Customers must open **My Orders**; admins see new orders live (red dot on the bell).
- Customers can't cancel orders themselves (that needs a stock-restoring function); they contact you and you cancel in admin.
- Product photos are stored inside Firestore (compressed) because Firebase Storage was not set up.
- `admin/inquiry-details.html` is an old sample-data page that nothing links to; inquiry handling lives in `inquiry-management.html`.
