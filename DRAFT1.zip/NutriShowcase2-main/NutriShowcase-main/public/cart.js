import { db } from "../firebase/firebase.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";
import { STORE } from "./config.js";
import {
    initHeaderMenus, getCart, saveCart, escapeHTML, formatPeso, productImage, toast
} from "./site.js";

initHeaderMenus();

const itemsEl = document.getElementById("cartItems");
const summaryEl = document.getElementById("cartSummary");
const subtotalEl = document.getElementById("sumSubtotal");
const totalEl = document.getElementById("sumTotal");
const noteEl = document.getElementById("sumNote");
const checkoutButton = document.getElementById("checkoutButton");

let lines = []; // {id, quantity, product|null}

async function loadLines() {
    const cart = getCart();
    const results = await Promise.all(cart.map(async item => {
        try {
            const snap = await getDoc(doc(db, "products", item.id));
            return { ...item, product: snap.exists() ? { id: snap.id, ...snap.data() } : null };
        } catch (error) {
            console.error("Product load error:", error);
            return { ...item, product: null, failed: true };
        }
    }));
    lines = results;
}

function maxFor(product) {
    return Math.max(0, Math.min(Number(product?.stock) || 0, STORE.maxPerItem));
}

function isBuyable(line) {
    const p = line.product;
    return p && p.availability !== "unavailable" && p.status !== "inactive" && maxFor(p) > 0;
}

function persist() {
    saveCart(lines.filter(l => l.product || l.failed).map(l => ({ id: l.id, quantity: l.quantity })));
}

function render() {
    if (!lines.length) {
        summaryEl.hidden = true;
        itemsEl.innerHTML = `
            <div class="empty-box">
                <h2>Your cart is empty</h2>
                <p>Add something freshly baked to get started.</p>
                <a href="products.html" class="btn-primary">Browse Products</a>
            </div>`;
        return;
    }

    itemsEl.innerHTML = `<h2>Items (${lines.reduce((s, l) => s + l.quantity, 0)})</h2>` + lines.map(line => {
        const p = line.product;
        if (!p) {
            return `
                <div class="cart-item">
                    <img src="${escapeHTML(productImage(""))}" alt="">
                    <div>
                        <h3>${line.failed ? "Could not load this item" : "This product is no longer available"}</h3>
                        <p class="warn">${line.failed ? "Check your connection and refresh." : "It will be removed from your order."}</p>
                    </div>
                    <div class="cart-item-side">
                        <button class="link-button" data-action="remove" data-id="${escapeHTML(line.id)}">Remove</button>
                    </div>
                </div>`;
        }

        const max = maxFor(p);
        const buyable = isBuyable(line);
        const price = Number(p.price) || 0;
        let warn = "";
        if (!buyable) warn = "Sold out — remove it to continue.";
        else if (line.quantity > max) warn = `Only ${max} left — quantity adjusted.`;

        return `
            <div class="cart-item">
                <img src="${escapeHTML(productImage(p.productImage))}" alt="${escapeHTML(p.productName)}"
                     onerror="this.onerror=null;this.src='../images/featured-picture.png'">
                <div>
                    <h3>${escapeHTML(p.productName || "Product")}</h3>
                    <p class="unit">${formatPeso(price)} each${buyable ? ` · ${max} in stock` : ""}</p>
                    <div class="qty-control">
                        <button type="button" data-action="dec" data-id="${escapeHTML(line.id)}" aria-label="Decrease quantity" ${buyable ? "" : "disabled"}>−</button>
                        <span>${line.quantity}</span>
                        <button type="button" data-action="inc" data-id="${escapeHTML(line.id)}" aria-label="Increase quantity" ${buyable && line.quantity < max ? "" : "disabled"}>+</button>
                    </div>
                    ${warn ? `<p class="warn">${escapeHTML(warn)}</p>` : ""}
                </div>
                <div class="cart-item-side">
                    <span class="line-price">${formatPeso(price * line.quantity)}</span>
                    <button class="link-button" data-action="remove" data-id="${escapeHTML(line.id)}">Remove</button>
                </div>
            </div>`;
    }).join("");

    updateSummary();
}

function updateSummary() {
    const buyable = lines.filter(isBuyable);
    const subtotal = buyable.reduce((s, l) => s + (Number(l.product.price) || 0) * l.quantity, 0);

    summaryEl.hidden = false;
    subtotalEl.textContent = formatPeso(subtotal);
    totalEl.textContent = formatPeso(subtotal);

    const blocked = lines.some(l => !isBuyable(l));
    checkoutButton.disabled = !buyable.length || blocked;

    if (STORE.freeDeliveryOver > 0) {
        const remaining = STORE.freeDeliveryOver - subtotal;
        noteEl.textContent = remaining > 0
            ? `Delivery is ${formatPeso(STORE.deliveryFee)}. Add ${formatPeso(remaining)} more for free delivery. Pickup is always free.`
            : "You qualify for free delivery!";
    } else {
        noteEl.textContent = `Delivery is ${formatPeso(STORE.deliveryFee)}. Pickup is free.`;
    }
}

itemsEl.addEventListener("click", event => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const line = lines.find(l => l.id === button.dataset.id);
    if (!line) return;

    const action = button.dataset.action;

    if (action === "remove") {
        lines = lines.filter(l => l !== line);
    } else if (action === "inc") {
        line.quantity = Math.min(maxFor(line.product), line.quantity + 1);
    } else if (action === "dec") {
        line.quantity = line.quantity - 1;
        if (line.quantity <= 0) lines = lines.filter(l => l !== line);
    }

    persist();
    render();
});

checkoutButton.addEventListener("click", () => {
    if (checkoutButton.disabled) return;
    location.href = "checkout.html";
});

(async function init() {
    try {
        await loadLines();
        // clamp quantities to current stock
        lines.forEach(l => {
            if (l.product && isBuyable(l)) l.quantity = Math.min(l.quantity, maxFor(l.product));
        });
        persist();
        render();
    } catch (error) {
        console.error(error);
        itemsEl.innerHTML = `<p class="page-loading">Unable to load your cart. Please refresh.</p>`;
        toast("Unable to load your cart.", "error");
    }
})();
