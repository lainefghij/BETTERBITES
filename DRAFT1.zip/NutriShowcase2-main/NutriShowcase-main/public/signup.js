import { auth } from "../firebase/firebase.js";
import {
    createUserWithEmailAndPassword,
    updateProfile
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import { ensureProfile, googleSignIn, authErrorMessage, getRedirect } from "./auth-helpers.js";

const signupForm = document.getElementById("signupForm");
const signupMessage = document.getElementById("signupMessage");
const fullName = document.getElementById("fullName");
const email = document.getElementById("email");
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");
const phone = document.getElementById("phone");
const terms = document.getElementById("terms");
const submitButton = signupForm.querySelector('button[type="submit"]');

const redirect = getRedirect();
document.querySelectorAll(".switch-auth a").forEach(link => {
    if (/login\.html/.test(link.getAttribute("href") || "") && redirect !== "index.html") {
        link.setAttribute("href", "login.html?redirect=" + encodeURIComponent(redirect));
    }
});

document.querySelectorAll(".password-toggle").forEach(button => {
    button.addEventListener("click", () => {
        const target = document.getElementById(button.dataset.target);
        const show = target.type === "password";
        target.type = show ? "text" : "password";
        button.setAttribute("aria-label", show ? "Hide password" : "Show password");
    });
});

function setMessage(text, type = "") {
    signupMessage.textContent = text;
    signupMessage.className = "form-message" + (type ? " " + type : "");
}

function clearErrors() {
    document.querySelectorAll(".field-error").forEach(error => { error.textContent = ""; });
    setMessage("");
}

function showError(id, message) {
    document.getElementById(id).textContent = message;
}

signupForm.addEventListener("submit", async event => {
    event.preventDefault();
    clearErrors();

    let valid = true;
    const nameValue = fullName.value.trim();
    const emailValue = email.value.trim();
    const phoneValue = phone.value.trim();

    if (nameValue.length < 2) { showError("nameError", "Please enter your full name."); valid = false; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue)) { showError("emailError", "Please enter a valid email address."); valid = false; }
    if (password.value.length < 8) { showError("passwordError", "Password must be at least 8 characters."); valid = false; }
    if (password.value !== confirmPassword.value) { showError("confirmPasswordError", "Passwords do not match."); valid = false; }
    if (phoneValue && !/^[0-9+\-\s()]{7,20}$/.test(phoneValue)) { showError("phoneError", "Please enter a valid phone number."); valid = false; }
    if (!terms.checked) { showError("termsError", "Please agree to the Terms & Conditions."); valid = false; }

    if (!valid) {
        setMessage("Please check the highlighted fields.", "error");
        return;
    }

    submitButton.disabled = true;
    submitButton.textContent = "Creating account...";

    try {
        const credential = await createUserWithEmailAndPassword(auth, emailValue, password.value);
        await updateProfile(credential.user, { displayName: nameValue });
        await ensureProfile(credential.user, { fullName: nameValue, phone: phoneValue });
        setMessage("Account created! Redirecting...", "success");
        location.href = redirect;
    } catch (error) {
        console.error("Signup error:", error);
        setMessage(authErrorMessage(error), "error");
        submitButton.disabled = false;
        submitButton.textContent = "Create Account";
    }
});

document.getElementById("googleSignup").addEventListener("click", async () => {
    setMessage("");
    try {
        await googleSignIn();
        location.href = redirect;
    } catch (error) {
        console.error("Google sign-up error:", error);
        setMessage(authErrorMessage(error), "error");
    }
});
