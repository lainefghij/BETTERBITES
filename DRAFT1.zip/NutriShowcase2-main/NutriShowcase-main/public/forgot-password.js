import { auth } from "../firebase/firebase.js";
import { sendPasswordResetEmail } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import { authErrorMessage } from "./auth-helpers.js";

const form = document.getElementById("loginForm");
const message = document.getElementById("loginMessage");
const email = document.getElementById("email");
const button = form.querySelector('button[type="submit"]');

function setMessage(text, type = "") {
    message.textContent = text;
    message.className = "form-message" + (type ? " " + type : "");
}

form.addEventListener("submit", async event => {
    event.preventDefault();
    document.getElementById("emailError").textContent = "";
    setMessage("");

    const value = email.value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        document.getElementById("emailError").textContent = "Please enter a valid email address.";
        return;
    }

    button.disabled = true;
    button.textContent = "Sending...";

    try {
        await sendPasswordResetEmail(auth, value);
        setMessage("If an account exists for that email, a reset link has been sent. Check your inbox and spam folder.", "success");
    } catch (error) {
        console.error("Reset error:", error);
        // do not reveal whether an account exists
        if (error.code === "auth/user-not-found") {
            setMessage("If an account exists for that email, a reset link has been sent. Check your inbox and spam folder.", "success");
        } else {
            setMessage(authErrorMessage(error), "error");
        }
    } finally {
        button.disabled = false;
        button.textContent = "Send Reset Link";
    }
});
