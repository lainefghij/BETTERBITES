import { db } from "../firebase/firebase.js";
import {
    collection,
    query,
    where,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";
import {
    initHeaderMenus, requireLogin, escapeHTML, formatPeso, formatDate
} from "./site.js";

initHeaderMenus();

const listEl = document.getElementById("ordersList");
const banner = document.getElementById("placedBanner");
const placed = new URLSearchParams(location.search).get("placed");

const STATUS_LABELS = {
    pending: "Pending",
    confirmed: "Confirmed",
    preparing: "Preparing",
    ready: "Ready",
    completed: "Completed",
    cancelled: "Cancelled"
};

const STEPS = ["pending", "confirmed", "preparing", "ready", "completed"];

if (placed) {
    banner.textContent = `Thank you! Your order ${placed} was placed. We'll confirm it shortly.`;
    banner.classList.add("show");
}

function readyLabel(order) {
    return order.fulfillment === "delivery" ? "Out for delivery" : "Ready for pickup";
}

function statusLabel(order) {
    return order.status === "ready" ? readyLabel(order) : (STATUS_LABELS[order.status] || order.status);
}

function progress(order) {
    if (order.status === "cancelled") return "";
    const index = STEPS.indexOf(order.status);
    const labels = ["Placed", "Confirmed", "Preparing", readyLabel(order).replace("Out for delivery", "On the way").replace("Ready for pickup", "Ready"), "Done"];
    return `<div class="progress">${STEPS.map((_, i) =>
        `<div class="${i <= index ? "done" : ""}">${escapeHTML(labels[i])}</div>`).join("")}</div>`;
}

function render(orders) {
    if (!orders.length) {
        listEl.innerHTML = `
            <div class="shop-card empty-box">
                <h2>No orders yet</h2>
                <p>When you place an order, you can follow it here.</p>
                <a href="products.html" class="btn-primary">Start Shopping</a>
            </div>`;
        return;
    }

    listEl.innerHTML = orders.map(order => `
        <article class="order-card ${order.orderNumber === placed ? "highlight" : ""}">
            <div class="order-head">
                <div>
                    <h3>${escapeHTML(order.orderNumber || order.id)}</h3>
                    <small>Placed ${escapeHTML(formatDate(order.createdAt, true))}</small>
                </div>
                <span class="status-pill ${escapeHTML(order.status)}">${escapeHTML(statusLabel(order))}</span>
            </div>

            ${progress(order)}

            <ul class="order-items">
                ${(order.items || []).map(item => `
                    <li>
                        <span>${Number(item.quantity) || 0} × ${escapeHTML(item.name)}</span>
                        <span>${formatPeso(item.lineTotal ?? (item.price * item.quantity))}</span>
                    </li>`).join("")}
            </ul>

            <div class="order-foot">
                <span>
                    ${order.fulfillment === "delivery" ? "Delivery to " + escapeHTML(order.address || "—") : "Pickup"}
                    · ${escapeHTML(order.preferredDate || "")} ${escapeHTML(order.preferredTime || "")}<br>
                    Payment: ${order.paymentMethod === "gcash" ? "GCash" : "Cash"} (${order.paymentStatus === "paid" ? "paid" : "unpaid"})
                </span>
                <span>Total <strong>${formatPeso(order.total)}</strong></span>
            </div>
        </article>`).join("");
}

requireLogin(user => {
    const ordersQuery = query(collection(db, "orders"), where("userId", "==", user.uid));

    onSnapshot(ordersQuery, snapshot => {
        const orders = snapshot.docs
            .map(d => ({ id: d.id, ...d.data() }))
            .sort((a, b) => {
                const ta = a.createdAt?.toMillis ? a.createdAt.toMillis() : Date.now();
                const tb = b.createdAt?.toMillis ? b.createdAt.toMillis() : Date.now();
                return tb - ta;
            });
        render(orders);
    }, error => {
        console.error("Orders error:", error);
        listEl.innerHTML = `<p class="page-loading">Unable to load your orders. ${
            error.code === "permission-denied" ? "Check your Firestore rules." : "Please refresh."}</p>`;
    });
}, "my-orders.html");
