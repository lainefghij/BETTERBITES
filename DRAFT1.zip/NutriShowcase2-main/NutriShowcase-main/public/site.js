// Shared helpers for every customer-facing page:
// cart storage, login state in the header, and (optionally) header menus.
import { auth, db } from "../firebase/firebase.js";
import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";
import { STORE } from "./config.js";

/* ---------- formatting ---------- */

export function escapeHTML(value = "") {
    return String(value).replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[c]);
}

export function formatPeso(amount) {
    return new Intl.NumberFormat("en-PH", {
        style: "currency",
        currency: "PHP",
        minimumFractionDigits: 2
    }).format(Number(amount) || 0);
}

export function productImage(value) {
    const fallback = "../images/featured-picture.png";
    if (typeof value !== "string" || !value.trim()) return fallback;
    const image = value.trim();
    if (/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(image)) return image;
    try {
        const url = new URL(image);
        if (url.protocol === "https:" || url.protocol === "http:") return url.href;
    } catch { /* ignore */ }
    return fallback;
}

export function formatDate(value, withTime = false) {
    if (!value) return "—";
    const date = value.toDate ? value.toDate() : new Date(value);
    if (Number.isNaN(date.getTime())) return "—";
    return date.toLocaleString("en-PH", withTime
        ? { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" }
        : { month: "short", day: "numeric", year: "numeric" });
}

/* ---------- cart (stored in the browser) ---------- */

const CART_KEY = "nutriCart";

export function getCart() {
    try {
        const cart = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
        if (!Array.isArray(cart)) return [];
        return cart
            .map(item => ({
                id: String(item.id || ""),
                quantity: Math.max(0, Math.floor(Number(item.quantity) || 0))
            }))
            .filter(item => item.id && item.quantity > 0);
    } catch {
        return [];
    }
}

export function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    updateCartCount();
}

export function addToCart(id, quantity = 1, maxStock = STORE.maxPerItem) {
    const cart = getCart();
    const limit = Math.max(0, Math.min(Number(maxStock) || 0, STORE.maxPerItem));
    const existing = cart.find(item => item.id === id);
    const current = existing ? existing.quantity : 0;
    const next = Math.min(limit, current + quantity);

    if (next <= current) return { added: 0, reachedLimit: true, quantity: current };

    if (existing) existing.quantity = next;
    else cart.push({ id, quantity: next });

    saveCart(cart);
    return { added: next - current, reachedLimit: next >= limit, quantity: next };
}

export function clearCart() {
    saveCart([]);
}

export function updateCartCount() {
    const el = document.getElementById("cartCount");
    if (!el) return;
    el.textContent = getCart().reduce((sum, item) => sum + item.quantity, 0);
}

window.addEventListener("storage", event => {
    if (event.key === CART_KEY) updateCartCount();
});

/* ---------- toast ---------- */

let toastTimer;
export function toast(message, type = "info") {
    let el = document.getElementById("siteToast");
    if (!el) {
        el = document.createElement("div");
        el.id = "siteToast";
        el.className = "site-toast";
        el.setAttribute("role", "status");
        document.body.appendChild(el);
    }
    el.textContent = message;
    el.dataset.type = type;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 3000);
}

/* ---------- user / profile ---------- */

export async function getProfile(uid) {
    try {
        const snap = await getDoc(doc(db, "users", uid));
        return snap.exists() ? snap.data() : null;
    } catch (error) {
        console.error("Profile load error:", error);
        return null;
    }
}

export function requireLogin(callback, redirectTo) {
    const target = redirectTo || (location.pathname.split("/").pop() + location.search);
    onAuthStateChanged(auth, async user => {
        if (!user) {
            location.replace("login.html?redirect=" + encodeURIComponent(target));
            return;
        }
        const profile = await getProfile(user.uid);
        callback(user, profile);
    });
}

function applyHeaderUser(user, profile) {
    const nameEl = document.getElementById("profileName");
    const emailEl = document.getElementById("profileEmail");
    const statusEl = document.getElementById("profileStatus");
    const avatarEl = document.getElementById("profileAvatar");
    const loginLink = document.getElementById("profileLogin");

    if (user) {
        const name = profile?.fullName || user.displayName || user.email?.split("@")[0] || "Customer";
        if (nameEl) nameEl.textContent = name;
        if (emailEl) emailEl.textContent = user.email || "";
        if (statusEl) statusEl.textContent = profile?.role === "admin" ? "Admin" : "Member";
        if (avatarEl) avatarEl.textContent = name.charAt(0).toUpperCase();

        if (loginLink) {
            loginLink.href = "#";
            loginLink.innerHTML = `<span>⇤</span><span><strong>Log Out</strong><small>Sign out of your account</small></span>`;
            loginLink.onclick = async event => {
                event.preventDefault();
                try {
                    await signOut(auth);
                    location.href = "index.html";
                } catch (error) {
                    console.error("Logout error:", error);
                    toast("Unable to log out. Please try again.", "error");
                }
            };
        }
    } else {
        if (nameEl) nameEl.textContent = "Guest Customer";
        if (emailEl) emailEl.textContent = "Welcome to BETTERBITES!";
        if (statusEl) statusEl.textContent = "Guest";
        if (avatarEl) avatarEl.textContent = "G";
    }
}

onAuthStateChanged(auth, async user => {
    if (!user) {
        applyHeaderUser(null, null);
        return;
    }
    applyHeaderUser(user, null);
    applyHeaderUser(user, await getProfile(user.uid));
});

/* ---------- header menus (only for pages with no menu script of their own) ---------- */

export function initHeaderMenus() {
    const menuButton = document.getElementById("menuButton");
    const navigation = document.getElementById("navigation");
    const searchButton = document.getElementById("searchButton");
    const searchBox = document.getElementById("searchBox");
    const searchInput = document.getElementById("searchInput");
    const profileButton = document.getElementById("profileButton");
    const profileDropdown = document.getElementById("profileDropdown");

    const closeNav = () => {
        navigation?.classList.remove("show");
        menuButton?.setAttribute("aria-expanded", "false");
    };
    const closeSearch = () => {
        searchBox?.classList.remove("show");
        searchButton?.setAttribute("aria-expanded", "false");
    };
    const closeProfile = () => {
        if (profileDropdown) profileDropdown.hidden = true;
        profileButton?.setAttribute("aria-expanded", "false");
    };

    menuButton?.addEventListener("click", event => {
        event.stopPropagation();
        const open = navigation.classList.contains("show");
        closeSearch(); closeProfile();
        if (open) closeNav();
        else {
            navigation.classList.add("show");
            menuButton.setAttribute("aria-expanded", "true");
        }
    });

    searchButton?.addEventListener("click", event => {
        event.stopPropagation();
        const open = searchBox.classList.contains("show");
        closeNav(); closeProfile();
        if (open) closeSearch();
        else {
            searchBox.classList.add("show");
            searchButton.setAttribute("aria-expanded", "true");
            searchInput?.focus();
        }
    });

    searchInput?.addEventListener("keydown", event => {
        if (event.key === "Enter" && searchInput.value.trim()) {
            location.href = "products.html?search=" + encodeURIComponent(searchInput.value.trim());
        }
    });

    profileButton?.addEventListener("click", event => {
        event.stopPropagation();
        const open = !profileDropdown.hidden;
        closeNav(); closeSearch();
        if (open) closeProfile();
        else {
            profileDropdown.hidden = false;
            profileButton.setAttribute("aria-expanded", "true");
        }
    });

    profileDropdown?.addEventListener("click", event => event.stopPropagation());

    document.addEventListener("click", event => {
        if (!navigation?.contains(event.target)) closeNav();
        if (!searchBox?.contains(event.target)) closeSearch();
        closeProfile();
    });

    document.addEventListener("keydown", event => {
        if (event.key === "Escape") { closeNav(); closeSearch(); closeProfile(); }
    });
}

updateCartCount();
