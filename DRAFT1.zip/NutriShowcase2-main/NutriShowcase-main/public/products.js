
import { db } from "../firebase/firebase.js";

import {
    collection,
    getDocs,
    query,
    where
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

import { addToCart, toast } from "./site.js";



const productGrid = document.getElementById("productGrid");
const productSearch = document.getElementById("productSearch");
const categoryButtons = document.querySelectorAll(".category");
const categories = document.getElementById("categories");
const noResults = document.getElementById("noResults");
const productMessage = document.getElementById("productMessage");
const productCount = document.getElementById("productCount");
const filterButton = document.getElementById("filterButton");

const searchButton = document.getElementById("searchButton");
const searchBox = document.getElementById("searchBox");
const searchInput = document.getElementById("searchInput");

const menuButton = document.getElementById("menuButton");
const navigation = document.getElementById("navigation");

const profileButton = document.getElementById("profileButton");
const profileDropdown = document.getElementById("profileDropdown");

const cartCount = document.getElementById("cartCount");

const allowedBadges = [
    "High Protein",
    "Iron Fortified",
    "Vitamin A Enriched"
];

let products = [];
let selectedCategory = "all";

function escapeHTML(value = "") {
    return String(value).replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

function formatPrice(price) {
    if (price === null || price === undefined || price === "") {
        return "Price upon inquiry";
    }

    const amount = Number(price);

    if (!Number.isFinite(amount) || amount < 0) {
        return "Price upon inquiry";
    }

    return new Intl.NumberFormat("en-PH", {
        style: "currency",
        currency: "PHP",
        maximumFractionDigits: 2
    }).format(amount);
}

function getBadges(badges) {
    if (!Array.isArray(badges)) {
        return [];
    }

    return badges.filter(badge => allowedBadges.includes(badge));
}

function getImageUrl(imageUrl) {
    if (typeof imageUrl !== "string" || !imageUrl.trim()) {
        return "../images/featured-picture.png";
    }

    const image = imageUrl.trim();

    if (/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(image)) {
        return image;
    }

    try {
        const url = new URL(image);

        if (url.protocol === "https:" || url.protocol === "http:") {
            return url.href;
        }
    } catch {
        return "../images/featured-picture.png";
    }

    return "../images/featured-picture.png";
}
    
   

function stockLabel(stock) {
    if (stock <= 0) return `<p class="stock-label out">Sold out</p>`;
    if (stock <= 5) return `<p class="stock-label low">Only ${stock} left</p>`;
    return `<p class="stock-label">In stock</p>`;
}

/* PRODUCT DISPLAY */

function renderProducts() {
    if (!productGrid || !productSearch) return;

    const query = productSearch.value.trim().toLowerCase();

    const filteredProducts = products.filter(product => {
        const name = String(product.productName || product.name || "").toLowerCase();
        const description = String(product.description || "").toLowerCase();
        const category = String(product.category || "").toLowerCase();

        const matchesSearch =
            name.includes(query) ||
            description.includes(query);

        const matchesCategory =
            selectedCategory === "all" ||
            category.includes(selectedCategory);

        return matchesSearch && matchesCategory;
    });

    productCount.textContent =
        `${filteredProducts.length} ${filteredProducts.length === 1 ? "product" : "products"}`;

    productGrid.innerHTML = filteredProducts.map(product => {
        const badges = getBadges(product.nutritionBadges);
        const stock = Math.max(0, Math.floor(Number(product.stock) || 0));

        const badgeHTML = badges.map(badge => `
            <span class="nutrition-badge">${escapeHTML(badge)}</span>
        `).join("");

        return `
            <article class="product-card">
                <img
                    src="${escapeHTML(getImageUrl(product.productImage || product.imageUrl))}"
                    alt="${escapeHTML(product.productName || product.name || "Baked product")}"
                    loading="lazy"
                    onerror="this.onerror=null;this.src='../images/featured-picture.png';"
                >

                <div class="product-info">
                    <div class="nutrition-badges">
                        ${badgeHTML}
                    </div>

                    <h2>${escapeHTML(product.productName || product.name || "Untitled Product")}</h2>

                    <p class="description">
                        ${escapeHTML(product.description || "")}
                    </p>

                    <p class="price">${formatPrice(product.price)}</p>

                    ${stockLabel(stock)}

                    <button
                        type="button"
                        class="add-to-cart"
                        data-id="${escapeHTML(product.id)}"
                        ${stock > 0 ? "" : "disabled"}
                    >${stock > 0 ? "Add to Cart" : "Sold Out"}</button>
                </div>
            </article>
        `;
    }).join("");

    noResults.hidden = filteredProducts.length > 0;
    productMessage.hidden = true;
}

/* LOAD FIRESTORE PRODUCTS */

async function loadProducts() {
    productMessage.hidden = false;
    productMessage.textContent = "Loading products...";
    productCount.textContent = "Loading...";

    try {
        const productsQuery = query(
    collection(db, "products"),
    where("status", "==", "active")
);

const snapshot = await getDocs(productsQuery);
        products = snapshot.docs
            .map(document => ({
                id: document.id,
                ...document.data()
            }))
            .filter(product =>
    (product.availability === "available" || product.available === true) &&
    (product.status === undefined || product.status === "active")
);

        if (products.length === 0) {
            productGrid.innerHTML = "";
            productMessage.hidden = false;
            productMessage.textContent = "No available products yet.";
            productCount.textContent = "0 products";
            noResults.hidden = true;
            return;
        }

        renderProducts();

    } catch (error) {
        console.error("Error loading products:", error);

        productGrid.innerHTML = "";
        productMessage.hidden = false;
        productMessage.textContent =
            "Unable to load products. Check your Firebase configuration and Firestore rules.";

        productCount.textContent = "Products unavailable";
        noResults.hidden = true;
    }
}

/* NAVIGATION */

function closeNavigation() {
    if (!navigation || !menuButton) return;

    navigation.classList.remove("show");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation");
}

if (menuButton && navigation) {
    menuButton.addEventListener("click", () => {
        const isOpen = navigation.classList.contains("show");

        closeSearch();
        closeProfile();

        if (isOpen) {
            closeNavigation();
        } else {
            navigation.classList.add("show");
            menuButton.setAttribute("aria-expanded", "true");
            menuButton.setAttribute("aria-label", "Close navigation");
        }
    });

    navigation.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", closeNavigation);
    });
}

/* HEADER SEARCH */

function closeSearch() {
    if (!searchBox || !searchButton) return;

    searchBox.classList.remove("show");
    searchButton.setAttribute("aria-expanded", "false");
}

if (searchButton && searchBox && searchInput) {
    searchButton.addEventListener("click", () => {
        const isOpen = searchBox.classList.contains("show");

        if (isOpen) {
            closeSearch();
        } else {
            closeNavigation();
            closeProfile();

            searchBox.classList.add("show");
            searchButton.setAttribute("aria-expanded", "true");
            searchInput.focus();
        }
    });

    searchInput.addEventListener("input", () => {
        productSearch.value = searchInput.value;
        renderProducts();
    });
}

/* PRODUCT SEARCH */

productSearch.addEventListener("input", () => {
    searchInput.value = productSearch.value;
    renderProducts();
});

/* CATEGORY FILTER */

categoryButtons.forEach(button => {
    button.addEventListener("click", () => {
        categoryButtons.forEach(categoryButton => {
            categoryButton.classList.remove("active");
        });

        button.classList.add("active");
        selectedCategory = button.dataset.category || "all";

        renderProducts();
    });
});

/* FILTER BUTTON */

if (filterButton && categories) {
    filterButton.addEventListener("click", () => {
        const isOpen = categories.classList.toggle("filter-open");

        filterButton.setAttribute("aria-expanded", String(isOpen));
    });
}

/* PROFILE DROPDOWN */

function openProfile() {
    if (!profileDropdown || !profileButton) return;

    profileDropdown.hidden = false;
    profileButton.setAttribute("aria-expanded", "true");
}

function closeProfile() {
    if (!profileDropdown || !profileButton) return;

    profileDropdown.hidden = true;
    profileButton.setAttribute("aria-expanded", "false");
}

if (profileButton && profileDropdown) {
    profileButton.addEventListener("click", () => {
        const isOpen = !profileDropdown.hidden;

        if (isOpen) {
            closeProfile();
        } else {
            closeNavigation();
            closeSearch();
            openProfile();
        }
    });

    document.addEventListener("click", event => {
        if (
            !profileDropdown.contains(event.target) &&
            !profileButton.contains(event.target)
        ) {
            closeProfile();
        }
    });
}

/* ESCAPE KEY */

document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
        closeNavigation();
        closeSearch();
        closeProfile();
    }
});

/* CART COUNT */

function updateCartCount() {
    if (!cartCount) return;

    try {
        const cart = JSON.parse(
            localStorage.getItem("nutriCart") || "[]"
        );

        const totalItems = Array.isArray(cart)
            ? cart.reduce((total, item) => {
                return total + Math.max(
                    0,
                    Number(item.quantity) || 0
                );
            }, 0)
            : 0;

        cartCount.textContent = totalItems;

    } catch (error) {
        console.error("Unable to read cart:", error);
        cartCount.textContent = "0";
    }
}

window.addEventListener("storage", event => {
    if (event.key === "nutriCart") {
        updateCartCount();
    }
});

/* ADD TO CART */

productGrid.addEventListener("click", event => {
    const button = event.target.closest(".add-to-cart");

    if (!button || button.disabled) return;

    const product = products.find(item => item.id === button.dataset.id);

    if (!product) return;

    const stock = Math.max(0, Math.floor(Number(product.stock) || 0));
    const result = addToCart(product.id, 1, stock);
    const name = product.productName || product.name || "Item";

    updateCartCount();

    if (result.added === 0) {
        toast(`You already have all ${stock} available ${name} in your cart.`, "error");
    } else {
        toast(`${name} added to cart.`, "success");
    }
});

/* INITIALIZE */

const initialSearch = new URLSearchParams(location.search).get("search");

if (initialSearch) {
    productSearch.value = initialSearch;
    if (searchInput) searchInput.value = initialSearch;
}


updateCartCount();
loadProducts();
