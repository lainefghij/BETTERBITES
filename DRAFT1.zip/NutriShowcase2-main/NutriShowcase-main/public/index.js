const menuButton = document.getElementById("menuButton");
const navigation = document.getElementById("navigation");

const searchButton = document.getElementById("searchButton");
const searchBox = document.getElementById("searchBox");
const searchInput = document.getElementById("searchInput");

const noResults = document.getElementById("noResults");

const profileButton = document.getElementById("profileButton");
const profileDropdown = document.getElementById("profileDropdown");


// CLOSE NAVIGATION
function closeNavigation() {
    if (!navigation || !menuButton) return;

    navigation.classList.remove("show");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation");
}


// OPEN NAVIGATION
function openNavigation() {
    if (!navigation || !menuButton) return;

    navigation.classList.add("show");
    menuButton.setAttribute("aria-expanded", "true");
    menuButton.setAttribute("aria-label", "Close navigation");
}


// CLOSE SEARCH
function closeSearch(clearSearch = false) {
    if (!searchBox || !searchButton) return;

    searchBox.classList.remove("show");
    searchButton.setAttribute("aria-expanded", "false");

    if (clearSearch && searchInput) {
        searchInput.value = "";
        filterProducts("");
    }
}


// SEARCH PRODUCTS
function filterProducts(value) {
    const query = value.toLowerCase().trim();
    let count = 0;

    document.querySelectorAll("#productGrid .product-card").forEach(card => {
        const name = (
            card.dataset.name ||
            card.querySelector("h3")?.textContent ||
            ""
        ).toLowerCase();

        const matches = name.includes(query);

        card.hidden = !matches;

        if (matches) {
            count++;
        }
    });

    if (noResults) {
        noResults.hidden = count > 0;
    }
}


// OPEN PROFILE
function openProfile() {
    if (!profileDropdown || !profileButton) return;

    profileDropdown.hidden = false;

    profileButton.setAttribute("aria-expanded", "true");
}


// CLOSE PROFILE
function closeProfile() {
    if (!profileDropdown || !profileButton) return;

    profileDropdown.hidden = true;

    profileButton.setAttribute("aria-expanded", "false");
}


// TOGGLE PROFILE
function toggleProfile() {
    if (!profileDropdown) return;

    if (profileDropdown.hidden) {
        closeNavigation();
        closeSearch();
        openProfile();
    } else {
        closeProfile();
    }
}


// MOBILE NAVIGATION EVENTS
if (menuButton && navigation) {

    menuButton.addEventListener("click", () => {

        const isOpen = navigation.classList.contains("show");

        if (isOpen) {
            closeNavigation();
        } else {
            closeSearch();
            closeProfile();
            openNavigation();
        }

    });

    navigation.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", closeNavigation);
    });
}


// SEARCH EVENTS
if (searchButton && searchBox && searchInput) {

    searchButton.addEventListener("click", () => {

        const isOpen = searchBox.classList.contains("show");

        if (isOpen) {
            closeSearch(true);
        } else {
            closeNavigation();
            closeProfile();

            searchBox.classList.add("show");

            searchButton.setAttribute("aria-expanded", "true");

            searchInput.focus();
        }

    });

    searchInput.addEventListener("input", event => {
        filterProducts(event.target.value);
    });
}


// PROFILE EVENTS
if (profileButton && profileDropdown) {

    profileButton.addEventListener("click", event => {
        event.stopPropagation();
        toggleProfile();
    });

    profileDropdown.addEventListener("click", event => {
        event.stopPropagation();
    });

}


// CLOSE WHEN CLICKING OUTSIDE
document.addEventListener("click", event => {

    if (
        profileDropdown &&
        profileButton &&
        !profileDropdown.contains(event.target) &&
        !profileButton.contains(event.target)
    ) {
        closeProfile();
    }

    if (
        navigation &&
        menuButton &&
        !navigation.contains(event.target) &&
        !menuButton.contains(event.target)
    ) {
        closeNavigation();
    }

});


// CLOSE WITH ESCAPE KEY
document.addEventListener("keydown", event => {

    if (event.key === "Escape") {
        closeNavigation();
        closeSearch(true);
        closeProfile();
    }

});


// INITIAL PRODUCT FILTER
filterProducts(searchInput?.value || "");