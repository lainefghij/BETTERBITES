// Homepage "Featured Products": shows the newest available products from Firestore.
import { db } from "../firebase/firebase.js";
import {
    collection,
    getDocs,
    query,
    where
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";
import { addToCart, toast, escapeHTML, formatPeso, productImage, updateCartCount } from "./site.js";

const grid = document.getElementById("productGrid");
let products = [];

function millis(value) {
    return value?.toMillis ? value.toMillis() : 0;
}

function render() {
    grid.innerHTML = products.map(product => {
        const stock = Math.max(0, Math.floor(Number(product.stock) || 0));
        const name = product.productName || "Product";

        return `
            <article class="product-card" data-name="${escapeHTML(name)}">
                <a href="products.html" class="product-image-link">
                    <img class="product-image" src="${escapeHTML(productImage(product.productImage))}"
                        alt="${escapeHTML(name)}"
                        onerror="this.onerror=null;this.src='../images/featured-picture.png'">
                </a>
                <div class="product-info">
                    <h3>${escapeHTML(name)}</h3>
                    <p class="price">${formatPeso(product.price)}</p>
                    <div class="badges">
                        <span class="fresh">Freshly Made</span>
                        <span class="stock">${stock > 0 ? "In Stock" : "Sold Out"}</span>
                    </div>
                    <button type="button" class="add-to-cart" data-id="${escapeHTML(product.id)}" ${stock > 0 ? "" : "disabled"}>
                        ${stock > 0 ? "Add to Cart" : "Sold Out"}
                    </button>
                </div>
            </article>`;
    }).join("");
}

grid?.addEventListener("click", event => {
    const button = event.target.closest(".add-to-cart");
    if (!button || button.disabled) return;

    const product = products.find(p => p.id === button.dataset.id);
    if (!product) return;

    const stock = Math.max(0, Math.floor(Number(product.stock) || 0));
    const result = addToCart(product.id, 1, stock);

    updateCartCount();
    toast(result.added ? `${product.productName} added to cart.` : "You already have all available stock in your cart.",
        result.added ? "success" : "error");
});

async function load() {
    if (!grid) return;

    try {
        const snapshot = await getDocs(query(collection(db, "products"), where("status", "==", "active")));

        products = snapshot.docs
            .map(d => ({ id: d.id, ...d.data() }))
            .filter(p => p.availability !== "unavailable")
            .sort((a, b) => millis(b.createdAt) - millis(a.createdAt))
            .slice(0, 4);

        if (products.length) {
            render();
        } else {
            grid.innerHTML = `<p class="loading-products">Fresh products are coming soon. Please check back later.</p>`;
        }

    } catch (error) {
        console.error("Featured products error:", error);
        grid.innerHTML = `<p class="loading-products">Unable to load products right now.</p>`;
    }
}

load();
