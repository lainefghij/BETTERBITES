// ==========================================
// BETTERBITES - INQUIRY PAGE
// ==========================================

// HEADER ELEMENTS

import { auth, db } from "../firebase/firebase.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import {
    collection,
    getDocs,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";
import "./site.js";

const navigation = document.getElementById("navigation");
const menuButton = document.getElementById("menuButton");

const searchButton = document.getElementById("searchButton");
const searchBox = document.getElementById("searchBox");
const searchInput = document.getElementById("searchInput");

const profileButton = document.getElementById("profileButton");
const profileDropdown = document.getElementById("profileDropdown");
const profileWrapper = document.querySelector(".profile-menu-wrapper");

// ==========================================
// MOBILE NAVIGATION
// ==========================================

function closeNavigation() {
    if (!navigation || !menuButton) return;

    navigation.classList.remove("show");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation");
}

if (menuButton && navigation) {
    menuButton.addEventListener("click", () => {
        const isOpen = navigation.classList.contains("show");

        if (isOpen) {
            closeNavigation();
        } else {
            navigation.classList.add("show");
            menuButton.setAttribute("aria-expanded", "true");
            menuButton.setAttribute("aria-label", "Close navigation");

            closeSearch();
            closeProfile();
        }
    });

    navigation.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", closeNavigation);
    });
}

// ==========================================
// SEARCH
// ==========================================

function closeSearch() {
    if (!searchBox || !searchButton) return;

    searchBox.classList.remove("show");
    searchButton.setAttribute("aria-expanded", "false");
}

if (searchButton && searchBox && searchInput) {
    searchButton.addEventListener("click", () => {
        const isOpen = searchBox.classList.contains("show");

        if (isOpen) {
            closeSearch();
        } else {
            closeNavigation();
            closeProfile();

            searchBox.classList.add("show");
            searchButton.setAttribute("aria-expanded", "true");

            searchInput.focus();
        }
    });

    searchInput.addEventListener("keydown", event => {
        if (event.key === "Enter") {
            const searchValue = searchInput.value.trim();

            if (searchValue) {
                window.location.href =
                    "products.html?search=" +
                    encodeURIComponent(searchValue);
            }
        }
    });
}

// ==========================================
// PROFILE DROPDOWN
// ==========================================

function openProfile() {
    if (!profileButton || !profileDropdown) return;

    profileDropdown.hidden = false;
    profileButton.setAttribute("aria-expanded", "true");
}

function closeProfile() {
    if (!profileButton || !profileDropdown) return;

    profileDropdown.hidden = true;
    profileButton.setAttribute("aria-expanded", "false");
}

if (profileButton && profileDropdown) {
    profileButton.addEventListener("click", event => {
        event.stopPropagation();

        const isOpen = !profileDropdown.hidden;

        if (isOpen) {
            closeProfile();
        } else {
            closeNavigation();
            closeSearch();
            openProfile();
        }
    });

    profileDropdown.addEventListener("click", event => {
        event.stopPropagation();
    });
}

// ==========================================
// CLOSE MENUS WHEN CLICKING OUTSIDE
// ==========================================

document.addEventListener("click", event => {

    if (
        profileWrapper &&
        !profileWrapper.contains(event.target)
    ) {
        closeProfile();
    }

    if (
        navigation &&
        menuButton &&
        !navigation.contains(event.target) &&
        !menuButton.contains(event.target)
    ) {
        closeNavigation();
    }

    if (
        searchBox &&
        searchButton &&
        !searchBox.contains(event.target) &&
        !searchButton.contains(event.target)
    ) {
        closeSearch();
    }
});

// ==========================================
// ESCAPE KEY
// ==========================================

document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
        closeNavigation();
        closeSearch();
        closeProfile();
    }
});

// ==========================================
// CART COUNT
// ==========================================

function updateCartCount() {
    const cartCount = document.getElementById("cartCount");

    if (!cartCount) return;

    try {
        const cart = JSON.parse(
            localStorage.getItem("nutriCart")
        ) || [];

        const total = cart.reduce(
            (sum, item) => {
                return sum + (Number(item.quantity) || 0);
            },
            0
        );

        cartCount.textContent = total;

    } catch (error) {
        cartCount.textContent = "0";
    }
}

updateCartCount();

// ==========================================
// PREFERRED DATE
// PREVENT PAST DATES
// ==========================================

const preferredDate = document.getElementById("preferredDate");

if (preferredDate) {
    const today = new Date();

    const localToday = [
        today.getFullYear(),
        String(today.getMonth() + 1).padStart(2, "0"),
        String(today.getDate()).padStart(2, "0")
    ].join("-");

    preferredDate.min = localToday;
}

// ==========================================
// PRODUCT SELECTION (loaded from Firestore)
// ==========================================

const productTableBody = document.querySelector(".product-table tbody");
const grandTotalElement = document.getElementById("grandTotal");
const selectionNote = document.getElementById("selectionNote");
const formMessage = document.getElementById("formMessage");
const inquiryForm = document.getElementById("inquiryForm");

let productRows = [];
let currentUser = null;

onAuthStateChanged(auth, user => {
    currentUser = user;

    if (user) {
        const nameInput = document.getElementById("fullName");
        const emailInput = document.getElementById("email");

        if (nameInput && !nameInput.value) nameInput.value = user.displayName || "";
        if (emailInput && !emailInput.value) emailInput.value = user.email || "";
    }
});

function escapeHTML(value = "") {
    return String(value).replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[c]);
}

function formatPeso(amount) {
    return "₱ " + Number(amount).toLocaleString("en-PH", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function safeImage(value) {
    if (typeof value === "string" && /^data:image\/(jpeg|jpg|png|webp);base64,/i.test(value)) return value;
    if (typeof value === "string" && /^https?:\/\//i.test(value)) return value;
    return "../images/featured-picture.png";
}

async function loadProductRows() {
    productTableBody.innerHTML =
        `<tr><td colspan="4">Loading products...</td></tr>`;

    try {
        const snapshot = await getDocs(collection(db, "products"));

        const products = snapshot.docs
            .map(d => ({ id: d.id, ...d.data() }))
            .filter(p => p.status !== "inactive" && p.availability !== "unavailable")
            .sort((a, b) => String(a.productName).localeCompare(String(b.productName)));

        if (!products.length) {
            productTableBody.innerHTML =
                `<tr><td colspan="4">No products are available yet. You can still describe your request in the message box.</td></tr>`;
            return;
        }

        productTableBody.innerHTML = products.map(p => `
            <tr class="product-row" data-price="${Number(p.price) || 0}" data-id="${escapeHTML(p.id)}">
                <td class="product-cell">
                    <input class="product-check" type="checkbox"
                        id="product_${escapeHTML(p.id)}" name="products"
                        value="${escapeHTML(p.productName)}">
                    <label class="product-label" for="product_${escapeHTML(p.id)}">
                        <img src="${escapeHTML(safeImage(p.productImage))}"
                            alt="${escapeHTML(p.productName)}" class="product-thumb"
                            onerror="this.onerror=null;this.src='../images/featured-picture.png'">
                        <span>${escapeHTML(p.productName)}</span>
                    </label>
                </td>
                <td class="unit-price">${formatPeso(Number(p.price) || 0)}</td>
                <td>
                    <div class="quantity-control">
                        <button type="button" class="quantity-btn decrease">−</button>
                        <input class="quantity-input" type="number"
                            min="0" max="999" step="1" value="0">
                        <button type="button" class="quantity-btn increase">+</button>
                    </div>
                </td>
                <td class="line-total">₱ 0.00</td>
            </tr>
        `).join("");

        bindRows();

        // product passed from another page: inquiry.html?product=<id>
        const wanted = new URLSearchParams(location.search).get("product");
        if (wanted) {
            const row = productTableBody.querySelector(`[data-id="${CSS.escape(wanted)}"]`);
            if (row) {
                row.querySelector(".quantity-input").value = 1;
                row.querySelector(".product-check").checked = true;
            }
        }

        updateTotals();

    } catch (error) {
        console.error("Product load error:", error);
        productTableBody.innerHTML =
            `<tr><td colspan="4">Unable to load products. You can still describe your request in the message box.</td></tr>`;
    }
}

function updateTotals() {
    let grandTotal = 0;
    let selectedCount = 0;

    productRows.forEach(row => {
        const price = Number(row.dataset.price);
        const checkbox = row.querySelector(".product-check");
        const quantityInput = row.querySelector(".quantity-input");
        const lineTotalElement = row.querySelector(".line-total");

        let quantity = Math.max(0, Math.min(999, Math.floor(Number(quantityInput.value) || 0)));

        if (checkbox.checked && quantity === 0) quantity = 1;
        if (!checkbox.checked) quantity = 0;

        quantityInput.value = quantity;

        const lineTotal = price * quantity;
        lineTotalElement.textContent = formatPeso(lineTotal);

        grandTotal += lineTotal;
        if (quantity > 0) selectedCount++;

        row.classList.toggle("selected", checkbox.checked);
    });

    if (grandTotalElement) grandTotalElement.textContent = formatPeso(grandTotal);

    if (selectionNote) {
        selectionNote.textContent = selectedCount
            ? selectedCount + " product(s) selected."
            : "Optional: select products and quantities to include in your quote request.";
    }

    return { grandTotal, selectedCount };
}

function bindRows() {
    productRows = [...productTableBody.querySelectorAll(".product-row")];

    productRows.forEach(row => {
        const checkbox = row.querySelector(".product-check");
        const quantityInput = row.querySelector(".quantity-input");

        checkbox.addEventListener("change", () => {
            if (checkbox.checked && Number(quantityInput.value) < 1) quantityInput.value = 1;
            updateTotals();
        });

        quantityInput.addEventListener("input", () => {
            checkbox.checked = Number(quantityInput.value) > 0;
            updateTotals();
        });

        row.querySelector(".decrease").addEventListener("click", () => {
            quantityInput.value = Math.max(0, (Number(quantityInput.value) || 0) - 1);
            checkbox.checked = Number(quantityInput.value) > 0;
            updateTotals();
        });

        row.querySelector(".increase").addEventListener("click", () => {
            quantityInput.value = Math.min(999, (Number(quantityInput.value) || 0) + 1);
            checkbox.checked = true;
            updateTotals();
        });
    });
}

// ==========================================
// INQUIRY FORM SUBMISSION
// ==========================================

function showFormMessage(text, type) {
    formMessage.textContent = text;
    formMessage.className = "form-message " + type;
}

inquiryForm.addEventListener("submit", async event => {
    event.preventDefault();
    formMessage.textContent = "";
    formMessage.className = "form-message";

    if (!inquiryForm.reportValidity()) return;

    const totals = updateTotals();
    const message = document.getElementById("message").value.trim();

    const selectedProducts = productRows
        .filter(row => row.querySelector(".product-check").checked)
        .map(row => {
            const quantity = Number(row.querySelector(".quantity-input").value);
            const unitPrice = Number(row.dataset.price);

            return {
                productId: row.dataset.id,
                product: row.querySelector(".product-check").value,
                quantity,
                unitPrice,
                total: quantity * unitPrice
            };
        })
        .filter(item => item.quantity > 0);

    if (!selectedProducts.length && !message) {
        showFormMessage("Please select a product or describe your request in the message box.", "error");
        return;
    }

    const totalQuantity = selectedProducts.reduce((sum, item) => sum + item.quantity, 0);

    const productName = !selectedProducts.length
        ? "General inquiry"
        : selectedProducts.length > 1
            ? `${selectedProducts[0].product} +${selectedProducts.length - 1} more`
            : selectedProducts[0].product;

    const inquiry = {
        userId: currentUser ? currentUser.uid : "",
        customerName: document.getElementById("fullName").value.trim(),
        email: document.getElementById("email").value.trim(),
        contactNumber: document.getElementById("contactNumber").value.trim(),
        inquiryType: document.getElementById("purpose").value,
        productName,
        productId: selectedProducts.length === 1 ? selectedProducts[0].productId : "",
        quantity: totalQuantity,
        message,
        status: "new",
        address: document.getElementById("address").value.trim(),
        preferredDate: preferredDate ? preferredDate.value : "",
        products: selectedProducts,
        grandTotal: totals.grandTotal,
        response: "",
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
    };

    const submitButton = inquiryForm.querySelector('button[type="submit"]');
    const originalLabel = submitButton.textContent;

    try {
        submitButton.disabled = true;
        submitButton.textContent = "Sending...";

        await addDoc(collection(db, "inquiries"), inquiry);

        showFormMessage("Thank you! Your inquiry was sent. We will contact you soon.", "success");

        inquiryForm.reset();
        productRows.forEach(row => { row.querySelector(".quantity-input").value = 0; });
        updateTotals();

    } catch (error) {
        console.error("Inquiry submit error:", error);

        showFormMessage(
            error.code === "permission-denied"
                ? "Submission blocked by Firestore rules. Publish firebase/firestore.rules."
                : "Could not send your inquiry. Please try again.",
            "error"
        );
    } finally {
        submitButton.disabled = false;
        submitButton.textContent = originalLabel;
    }
});

loadProductRows();
closeProfile();
closeNavigation();
closeSearch();
