import { initHeaderMenus } from "./site.js";
initHeaderMenus();
