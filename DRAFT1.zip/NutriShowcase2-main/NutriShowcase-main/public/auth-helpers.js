// Customer sign-in helpers shared by login.js / signup.js
import { auth, db } from "../firebase/firebase.js";
import {
    GoogleAuthProvider,
    signInWithPopup
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import {
    doc,
    getDoc,
    setDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

export function getRedirect() {
    const target = new URLSearchParams(location.search).get("redirect") || "";
    // only allow same-folder relative pages (no open redirects)
    return /^[a-z0-9\-]+\.html(\?[\w=&%\-.]*)?$/i.test(target) ? target : "index.html";
}

export function authErrorMessage(error) {
    switch (error?.code) {
        case "auth/invalid-credential":
        case "auth/user-not-found":
        case "auth/wrong-password":
            return "Incorrect email or password.";
        case "auth/email-already-in-use":
            return "An account with this email already exists. Try logging in.";
        case "auth/weak-password":
            return "Password is too weak. Use at least 8 characters.";
        case "auth/invalid-email":
            return "Please enter a valid email address.";
        case "auth/too-many-requests":
            return "Too many attempts. Please try again later.";
        case "auth/network-request-failed":
            return "Network error. Please check your internet connection.";
        case "auth/popup-closed-by-user":
        case "auth/cancelled-popup-request":
            return "Sign-in was cancelled.";
        case "auth/popup-blocked":
            return "Your browser blocked the sign-in popup. Please allow popups and try again.";
        case "auth/operation-not-allowed":
            return "This sign-in method is not enabled yet. Enable it in Firebase Authentication.";
        case "auth/unauthorized-domain":
            return "This website's domain is not authorized in Firebase Authentication settings.";
        case "permission-denied":
            return "Access denied by Firestore security rules. Publish the rules in firebase/firestore.rules.";
        default:
            return "Something went wrong. Please try again.";
    }
}

export async function ensureProfile(user, extra = {}) {
    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);
    if (snap.exists()) return snap.data();

    const profile = {
        fullName: extra.fullName || user.displayName || user.email?.split("@")[0] || "Customer",
        email: user.email || "",
        phone: extra.phone || "",
        role: "customer",
        status: "active",
        createdAt: serverTimestamp()
    };
    await setDoc(ref, profile);
    return profile;
}

export async function googleSignIn() {
    const result = await signInWithPopup(auth, new GoogleAuthProvider());
    await ensureProfile(result.user);
    return result.user;
}
