import { db } from "../firebase/firebase.js";
import {
    doc,
    collection,
    getDoc,
    runTransaction,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";
import { STORE } from "./config.js";
import {
    initHeaderMenus, requireLogin, getCart, clearCart, escapeHTML, formatPeso, toast
} from "./site.js";

initHeaderMenus();

const form = document.getElementById("checkoutForm");
const loading = document.getElementById("checkoutLoading");
const message = document.getElementById("checkoutMessage");
const placeButton = document.getElementById("placeOrderButton");

const fullName = document.getElementById("fullName");
const contactNumber = document.getElementById("contactNumber");
const email = document.getElementById("email");
const address = document.getElementById("address");
const addressField = document.getElementById("addressField");
const preferredDate = document.getElementById("preferredDate");
const preferredTime = document.getElementById("preferredTime");
const notes = document.getElementById("notes");
const gcashNote = document.getElementById("gcashNote");
const cashHint = document.getElementById("cashHint");
const deliveryHint = document.getElementById("deliveryHint");

let currentUser = null;
let lines = []; // { id, quantity, product }

function showMessage(text, type = "error") {
    message.textContent = text;
    message.className = "form-alert show " + type;
}

function fulfillment() {
    return form.querySelector('input[name="fulfillment"]:checked').value;
}

function payment() {
    return form.querySelector('input[name="payment"]:checked').value;
}

function computeTotals() {
    const subtotal = lines.reduce((s, l) => s + (Number(l.product.price) || 0) * l.quantity, 0);
    let deliveryFee = 0;
    if (fulfillment() === "delivery") {
        const free = STORE.freeDeliveryOver > 0 && subtotal >= STORE.freeDeliveryOver;
        deliveryFee = free ? 0 : STORE.deliveryFee;
    }
    return { subtotal, deliveryFee, total: subtotal + deliveryFee };
}

function renderSummary() {
    const { subtotal, deliveryFee, total } = computeTotals();

    document.getElementById("miniItems").innerHTML = lines.map(l => `
        <div class="mini-item">
            <span>${l.quantity} × ${escapeHTML(l.product.productName)}</span>
            <span>${formatPeso((Number(l.product.price) || 0) * l.quantity)}</span>
        </div>`).join("");

    document.getElementById("sumSubtotal").textContent = formatPeso(subtotal);
    document.getElementById("sumDelivery").textContent =
        fulfillment() === "delivery"
            ? (deliveryFee === 0 ? "Free" : formatPeso(deliveryFee))
            : "Pickup (free)";
    document.getElementById("sumTotal").textContent = formatPeso(total);
}

function refreshOptions() {
    const delivery = fulfillment() === "delivery";
    addressField.hidden = !delivery;
    address.required = delivery;
    cashHint.textContent = delivery ? "Pay the rider on delivery" : "Pay when you pick up";
    deliveryHint.textContent = STORE.deliveryFee > 0
        ? `${formatPeso(STORE.deliveryFee)}${STORE.freeDeliveryOver > 0 ? ` · free over ${formatPeso(STORE.freeDeliveryOver)}` : ""}`
        : "Delivered to your address";

    const gcash = payment() === "gcash";
    gcashNote.hidden = !gcash;
    if (gcash) {
        gcashNote.textContent =
            `After we confirm your order, send the total to GCash ${STORE.gcashNumber} (${STORE.gcashName}) and keep the receipt.`;
    }
    renderSummary();
}

form.addEventListener("change", refreshOptions);

function localToday() {
    const d = new Date();
    return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
}

function makeOrderNumber() {
    const d = new Date();
    const stamp = String(d.getFullYear()).slice(2) + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0");
    const rand = Math.random().toString(36).slice(2, 6).toUpperCase().padEnd(4, "0");
    return `BB-${stamp}-${rand}`;
}

async function loadLines() {
    const cart = getCart();
    const loaded = await Promise.all(cart.map(async item => {
        const snap = await getDoc(doc(db, "products", item.id));
        return snap.exists() ? { ...item, product: { id: snap.id, ...snap.data() } } : null;
    }));
    return loaded.filter(Boolean);
}

async function placeOrder(event) {
    event.preventDefault();
    message.className = "form-alert";

    if (!form.reportValidity()) return;

    const nameValue = fullName.value.trim();
    const phoneValue = contactNumber.value.trim();

    if (nameValue.length < 2) return showMessage("Please enter your full name.");
    if (!/^[0-9+\-\s()]{7,20}$/.test(phoneValue)) return showMessage("Please enter a valid contact number.");
    if (preferredDate.value < localToday()) return showMessage("Preferred date cannot be in the past.");
    if (fulfillment() === "delivery" && address.value.trim().length < 8) {
        return showMessage("Please enter a complete delivery address.");
    }

    placeButton.disabled = true;
    placeButton.textContent = "Placing order...";

    const orderRef = doc(collection(db, "orders"));
    const orderNumber = makeOrderNumber();

    try {
        await runTransaction(db, async tx => {
            const productRefs = lines.map(l => doc(db, "products", l.id));
            const snaps = [];
            for (const ref of productRefs) snaps.push(await tx.get(ref));

            const items = [];
            let subtotal = 0;

            snaps.forEach((snap, index) => {
                const line = lines[index];

                if (!snap.exists()) {
                    throw new Error(`"${line.product.productName}" is no longer available.`);
                }

                const data = snap.data();
                const stock = Number(data.stock) || 0;

                if (data.availability === "unavailable" || data.status === "inactive") {
                    throw new Error(`"${data.productName}" is currently unavailable.`);
                }
                if (stock < line.quantity) {
                    throw new Error(stock <= 0
                        ? `"${data.productName}" just sold out.`
                        : `Only ${stock} of "${data.productName}" left. Please update your cart.`);
                }

                const price = Number(data.price) || 0;
                subtotal += price * line.quantity;

                items.push({
                    productId: snap.id,
                    name: data.productName || "Product",
                    price,
                    quantity: line.quantity,
                    lineTotal: price * line.quantity
                });

                tx.update(productRefs[index], { stock: stock - line.quantity });
            });

            const delivery = fulfillment() === "delivery";
            const free = STORE.freeDeliveryOver > 0 && subtotal >= STORE.freeDeliveryOver;
            const deliveryFee = delivery && !free ? STORE.deliveryFee : 0;

            tx.set(orderRef, {
                orderNumber,
                userId: currentUser.uid,
                customerName: nameValue,
                email: currentUser.email || "",
                contactNumber: phoneValue,
                fulfillment: fulfillment(),
                address: delivery ? address.value.trim() : "",
                preferredDate: preferredDate.value,
                preferredTime: preferredTime.value,
                paymentMethod: payment(),
                paymentStatus: "unpaid",
                status: "pending",
                items,
                subtotal,
                deliveryFee,
                total: subtotal + deliveryFee,
                notes: notes.value.trim(),
                adminNotes: "",
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
        });

        clearCart();
        location.href = "my-orders.html?placed=" + encodeURIComponent(orderNumber);

    } catch (error) {
        console.error("Order error:", error);

        let text = error.message || "Could not place your order. Please try again.";
        if (error.code === "permission-denied") {
            text = "The order was blocked by Firestore security rules. Make sure firebase/firestore.rules is published.";
        } else if (error.code === "unavailable" || error.code === "failed-precondition") {
            text = "Network problem. Please check your connection and try again.";
        }

        showMessage(text);
        placeButton.disabled = false;
        placeButton.textContent = "Place Order";
    }
}

requireLogin(async (user, profile) => {
    currentUser = user;

    try {
        if (!getCart().length) {
            location.replace("cart.html");
            return;
        }

        lines = await loadLines();

        if (!lines.length) {
            location.replace("cart.html");
            return;
        }

        fullName.value = profile?.fullName || user.displayName || "";
        contactNumber.value = profile?.phone || "";
        email.value = user.email || "";

        preferredDate.min = localToday();
        preferredDate.value = localToday();

        refreshOptions();

        loading.hidden = true;
        form.hidden = false;
        form.addEventListener("submit", placeOrder);

    } catch (error) {
        console.error("Checkout load error:", error);
        loading.textContent = "Unable to load checkout. Please refresh the page.";
        toast("Unable to load checkout.", "error");
    }
}, "checkout.html");
