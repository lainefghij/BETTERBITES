// Store settings - edit these to match your business.
export const STORE = {
    name: "BETTERBITES",
    deliveryFee: 50,            // flat delivery fee in PHP
    freeDeliveryOver: 1000,     // free delivery when subtotal reaches this amount (0 = never free)
    maxPerItem: 99,             // max quantity per product in one order
    gcashNumber: "09XX XXX XXXX", // shown to customers who choose GCash
    gcashName: "Your Business Name",
    pickupAddress: "Your business address",
    contactNumber: "Your contact number"
};
