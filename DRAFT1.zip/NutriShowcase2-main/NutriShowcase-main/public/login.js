import { auth } from "../firebase/firebase.js";
import {
    signInWithEmailAndPassword,
    setPersistence,
    browserLocalPersistence,
    browserSessionPersistence,
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import { ensureProfile, googleSignIn, authErrorMessage, getRedirect } from "./auth-helpers.js";

const loginForm = document.getElementById("loginForm");
const loginMessage = document.getElementById("loginMessage");
const email = document.getElementById("email");
const password = document.getElementById("password");
const rememberMe = document.getElementById("rememberMe");
const submitButton = loginForm.querySelector('button[type="submit"]');
const googleButton = document.getElementById("googleLogin");

function setMessage(text, type = "") {
    loginMessage.textContent = text;
    loginMessage.className = "form-message" + (type ? " " + type : "");
}

// keep the "continue as guest" link and sign-up link pointing the right way
const redirect = getRedirect();
document.querySelector(".switch-auth a")?.setAttribute(
    "href",
    "signup.html" + (redirect !== "index.html" ? "?redirect=" + encodeURIComponent(redirect) : "")
);

// SHOW / HIDE PASSWORD
document.querySelectorAll(".password-toggle").forEach(button => {
    button.addEventListener("click", () => {
        const target = document.getElementById(button.dataset.target);
        const show = target.type === "password";
        target.type = show ? "text" : "password";
        button.setAttribute("aria-label", show ? "Hide password" : "Show password");
    });
});

// already signed in? skip the form
let handledSubmit = false;
onAuthStateChanged(auth, user => {
    if (user && !handledSubmit) location.replace(redirect);
});

loginForm.addEventListener("submit", async event => {
    event.preventDefault();

    document.getElementById("emailError").textContent = "";
    document.getElementById("passwordError").textContent = "";
    setMessage("");

    const emailValue = email.value.trim();
    let valid = true;

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue)) {
        document.getElementById("emailError").textContent = "Please enter a valid email address.";
        valid = false;
    }
    if (!password.value) {
        document.getElementById("passwordError").textContent = "Please enter your password.";
        valid = false;
    }
    if (!valid) {
        setMessage("Please check the highlighted fields.", "error");
        return;
    }

    submitButton.disabled = true;
    submitButton.textContent = "Logging in...";
    handledSubmit = true;

    try {
        await setPersistence(auth, rememberMe.checked ? browserLocalPersistence : browserSessionPersistence);
        const credential = await signInWithEmailAndPassword(auth, emailValue, password.value);
        await ensureProfile(credential.user);
        setMessage("Login successful! Redirecting...", "success");
        location.href = redirect;
    } catch (error) {
        console.error("Login error:", error);
        handledSubmit = false;
        setMessage(authErrorMessage(error), "error");
        submitButton.disabled = false;
        submitButton.textContent = "Log In";
    }
});

googleButton.addEventListener("click", async () => {
    setMessage("");
    handledSubmit = true;
    try {
        await googleSignIn();
        setMessage("Login successful! Redirecting...", "success");
        location.href = redirect;
    } catch (error) {
        console.error("Google sign-in error:", error);
        handledSubmit = false;
        setMessage(authErrorMessage(error), "error");
    }
});
