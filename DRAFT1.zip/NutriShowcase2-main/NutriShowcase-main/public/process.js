
import { db } from "../firebase/firebase.js";

import {
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

document.addEventListener("DOMContentLoaded", function () {
    const profileButton = document.getElementById("profileButton");
    const profileDropdown = document.getElementById("profileDropdown");
    const profileWrapper = document.querySelector(".profile-menu-wrapper");

    function closeProfile() {
        if (!profileDropdown || !profileButton) return;
        profileDropdown.hidden = true;
        profileButton.setAttribute("aria-expanded", "false");
    }

    function toggleProfile() {
        if (!profileDropdown || !profileButton) return;

        const isOpen = profileDropdown.hidden;
        profileDropdown.hidden = !isOpen;
        profileButton.setAttribute("aria-expanded", String(isOpen));
    }

    if (profileButton && profileDropdown) {
        profileButton.addEventListener("click", function (event) {
            event.stopPropagation();
            toggleProfile();
        });

        profileDropdown.addEventListener("click", function (event) {
            event.stopPropagation();
        });

        document.addEventListener("click", function (event) {
            if (profileWrapper && !profileWrapper.contains(event.target)) {
                closeProfile();
            }
        });

        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape") closeProfile();
        });
    }

    const searchButton = document.getElementById("searchButton");
    const searchBox = document.getElementById("searchBox");
    const searchInput = document.getElementById("searchInput");

    if (searchButton && searchBox) {
        searchButton.addEventListener("click", function () {
            const isOpen = searchBox.classList.toggle("show");
            searchButton.setAttribute("aria-expanded", String(isOpen));

            if (isOpen && searchInput) searchInput.focus();
        });
    }

    if (searchInput) {
        searchInput.addEventListener("keydown", function (event) {
            if (event.key === "Enter") {
                const searchValue = searchInput.value.trim();

                if (searchValue) {
                    window.location.href =
                        "products.html?search=" + encodeURIComponent(searchValue);
                }
            }
        });
    }

    const menuButton = document.getElementById("menuButton");
    const navigation = document.getElementById("navigation");

    if (menuButton && navigation) {
        menuButton.addEventListener("click", function () {
            const isOpen = navigation.classList.toggle("show");
            menuButton.setAttribute("aria-expanded", String(isOpen));
        });

        navigation.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                navigation.classList.remove("show");
                menuButton.setAttribute("aria-expanded", "false");
            });
        });

        document.addEventListener("click", function (event) {
            if (
                !navigation.contains(event.target) &&
                !menuButton.contains(event.target)
            ) {
                navigation.classList.remove("show");
                menuButton.setAttribute("aria-expanded", "false");
            }
        });
    }

    const productSelect = document.getElementById("productSelect");
    const processContent = document.getElementById("processContent");

    const fallbackImage = "../images/featured-picture.png";

    let products = [];
    let processes = [];

    function escapeHTML(value = "") {
        return String(value).replace(/[&<>"']/g, character => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        })[character]);
    }

    function getImageUrl(value) {
        if (typeof value !== "string" || !value.trim()) {
            return fallbackImage;
        }

        const image = value.trim();

        if (/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(image)) {
            return image;
        }

        if (/^(https?:\/\/|\.{1,2}\/|images\/)/i.test(image)) {
            return image;
        }

        return fallbackImage;
    }

    function showMessage(message) {
        if (!processContent) return;

        processContent.innerHTML = `
            <div class="process-loading">
                ${escapeHTML(message)}
            </div>
        `;
    }

    function renderProductOptions() {
        if (!productSelect) return;

        productSelect.innerHTML = products.map(product => `
            <option value="${escapeHTML(product.id)}">
                ${escapeHTML(product.productName || product.name || "Untitled Product")}
            </option>
        `).join("");

    }

    function renderProcess(productId) {
        if (!processContent) return;

        const product = products.find(item => item.id === productId);

        if (!product) {
            showMessage("Product process information is unavailable.");
            return;
        }

        const productSteps = processes
            .filter(step =>
                String(step.productId).trim() === String(productId).trim() &&
                step.status === "active"
            )
            .sort((a, b) =>
                Number(a.stepNumber || 0) - Number(b.stepNumber || 0)
            );

        const productName = product.productName || product.name || "Baked Product";
        const productDescription = product.description || "";
        const productImage = getImageUrl(product.productImage || product.imageUrl);

        if (!productSteps.length) {
            processContent.innerHTML = `
                <article class="process-product">
                    <div class="product-overview">
                        <div class="product-overview-copy">
                            <span class="eyebrow">OUR BAKING PROCESS</span>
                            <h3>${escapeHTML(productName)}</h3>
                            <p>${escapeHTML(productDescription)}</p>
                        </div>
                        <div class="product-overview-image">
                            <img src="${escapeHTML(productImage)}"
                                 alt="${escapeHTML(productName)}"
                                 loading="lazy">
                        </div>
                    </div>
                    <div class="process-loading">
                        No active production steps are available for this product yet.
                    </div>
                </article>
            `;
            return;
        }

        const stepsHTML = productSteps.map((step, index) => {
            const stepNumber = String(step.stepNumber || index + 1).padStart(2, "0");

            return `
                <article class="process-step">
                    <span class="step-number">STEP ${stepNumber}</span>
                    <h4>${escapeHTML(step.stepTitle || "Untitled Step")}</h4>
                    <p>${escapeHTML(step.description || "")}</p>
                    ${step.duration ? `<span class="step-duration">${escapeHTML(step.duration)}</span>` : ""}
                </article>
            `;
        }).join("");

        processContent.innerHTML = `
            <article class="process-product">
                <div class="product-overview">
                    <div class="product-overview-copy">
                        <span class="eyebrow">OUR BAKING PROCESS</span>
                        <h3>${escapeHTML(productName)}</h3>
                        <p>${escapeHTML(productDescription)}</p>
                    </div>
                    <div class="product-overview-image">
                        <img
                            src="${escapeHTML(productImage)}"
                            alt="${escapeHTML(productName)}"
                            loading="lazy"
                            onerror="this.onerror=null;this.src='../images/featured-picture.png';"
                        >
                    </div>
                </div>

                <div class="process-step-heading">
                    <h3>Step-by-Step Preparation</h3>
                    <span class="step-count">${productSteps.length} STEPS</span>
                </div>

                <div class="process-timeline">
                    ${stepsHTML}
                </div>
            </article>
        `;
    }

    async function loadProcessData() {
        if (!productSelect || !processContent) return;

        showMessage("Loading production process...");

        try {
            const [productSnapshot, processSnapshot] = await Promise.all([
                getDocs(collection(db, "products")),
                getDocs(collection(db, "processes"))
            ]);

            products = productSnapshot.docs
                .map(document => ({
                    id: document.id,
                    ...document.data()
                }))
                .filter(product =>
                    product.status === "active" &&
                    (product.availability === "available" || product.available === true)
                );

            processes = processSnapshot.docs.map(document => ({
                id: document.id,
                ...document.data()
            }));

            if (!products.length) {
                productSelect.innerHTML = "";
                showMessage("No available products found.");
                return;
            }

            renderProductOptions();

            productSelect.addEventListener("change", function () {
                renderProcess(this.value);
            });

            renderProcess(productSelect.value);

        } catch (error) {
            console.error("Error loading public process page:", error);
            showMessage(
                "Unable to load the baking process. Please check your Firebase connection and Firestore permissions."
            );
        }
    }

    closeProfile();
    loadProcessData();
});
