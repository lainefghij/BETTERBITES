# NutriShowcase Firebase Setup and Deployment

This project is the existing plain HTML/CSS/JavaScript ES-module application (not a React + Vite application). Keep its current structure and run it through a local web server; do not open the HTML files with `file://`.

## Firebase project currently configured

The source currently points to Firebase project `betterbites-32937`. Confirm that this is the intended project before publishing anything. The Firebase web configuration in `firebase/firebase.js` is a client configuration; it is expected to be present in browser apps. Never place service-account JSON or Admin SDK private keys in this folder.

Services initialized in `firebase/firebase.js`:
- Firebase Authentication
- Cloud Firestore
- Firebase Storage

## Files added/updated

- `firebase/firestore.rules` — Firestore access controls for customers, admins, and staff.
- `firebase/storage.rules` — Storage access controls and image type/size limits.
- `firebase/storage-upload.js` — reusable upload helpers for product, process, and profile images. These helpers must be imported and wired to the corresponding HTML file inputs before image upload is available in the UI.
- `firebase/firestore.indexes.json` — index deployment file (currently no composite indexes are required by the inspected queries).
- `firebase.json` — connects Firestore and Storage rules to Firebase CLI deployment.
- `.firebaserc` — selects project `betterbites-32937`.

## A. Confirm the Firebase project

1. Open https://console.firebase.google.com/
2. Select project `betterbites-32937`.
3. If this is not your intended project, update `projectId`, `authDomain`, `storageBucket`, `messagingSenderId`, `appId` in `firebase/firebase.js` using the Web App config from Project settings > General > Your apps.
4. Update `.firebaserc` to the same project ID.
5. Ensure the Firebase Storage bucket name in the config matches the bucket shown in Storage.

## B. Enable Authentication

1. Firebase Console > Build > Authentication > Get started.
2. Open Sign-in method.
3. Enable **Email/Password**.
4. Authentication > Settings > Authorized domains: add `localhost` for local testing and your actual deployed domain for production.
5. Admin and staff accounts should be created through Authentication > Users > Add user (or a trusted server-side Admin SDK process). Do not provide public admin signup.

## C. Create the first admin profile

Firestore rules intentionally prevent a person from assigning themselves the `admin` or `staff` role.

1. Create the administrator account in Authentication > Users > Add user.
2. Copy that account's UID.
3. Firestore Database > Data > Start collection named `users`.
4. Use the Authentication UID as the document ID.
5. Add fields:
   - `fullName` — string, e.g. `System Administrator`
   - `email` — string, the account email
   - `phone` — string (optional)
   - `role` — string: `admin`
   - `status` — string: `active`
   - `createdAt` — timestamp
6. Save. Sign in through `admin/admin-login.html`.

To create staff, repeat the steps with `role` set to `staff`. The current admin pages check for the `admin` role, so staff access is not yet enabled in the admin-page UI even though the rules recognize staff for operational inquiry/order access. Do not give staff admin credentials.

## D. Create Firestore

1. Firebase Console > Build > Firestore Database > Create database.
2. Choose a location close to your users; database location cannot be changed later.
3. Create in production mode.
4. Do not manually create empty collections; the application creates documents when records are added.
5. Current collection names used by the code:
   - `users`
   - `products`
   - `processes`
   - `inquiries`
   - `orders` (the checkout code uses `orders`, not `preOrders`)

Product records use `productName`, `description`, `price`, `category`, `image`, `stock`, `status`, and `availability` fields in the current code. Process records are managed by the process management page. Inquiry and order fields are created by the public forms and checkout page.

## E. Enable Firebase Storage

1. Firebase Console > Build > Storage > Get started.
2. Create the default bucket and select the same region policy you intend to use.
3. Confirm `storageBucket` in `firebase/firebase.js` matches the console bucket.
4. The included Storage rules allow public viewing of product/process images, image upload by active admin/staff profiles, and each signed-in user to manage only their own profile image.
5. Allowed formats: JPEG, PNG, WebP. Maximum size: less than 5 MB.

Storage upload helpers are in `firebase/storage-upload.js`. Existing product/process forms were not rewritten to add file-input upload controls. To complete the UI integration, import `uploadImage` into the management page, upload the selected file, then save the returned `url` and `path` fields in the Firestore document. Delete the old Storage object when replacing/deleting an image, using `removeImage(path)`.

Example usage from a page module:
```js
import { uploadImage, removeImage } from "../firebase/storage-upload.js";

const file = document.querySelector("#productImageFile").files[0];
const uploaded = await uploadImage(file, "products");
const productData = {
    productName: "Sample product",
    image: uploaded.url,
    imagePath: uploaded.path
};
```
The file input ID above is an example; add a matching input to the page before using it.

## F. Publish Firestore and Storage rules

Install Node.js LTS, then install Firebase CLI in a terminal:
```bash
npm install -g firebase-tools
firebase login
```

Open a terminal in the extracted `NutriShowcase-main` project folder and run:
```bash
firebase use betterbites-32937
firebase deploy --only firestore:rules,firestore:indexes,storage
```

Review the CLI output. A successful deployment should confirm Firestore rules, Firestore indexes, and Storage rules were deployed. If the project ID differs, use the correct project ID consistently in `.firebaserc`, `firebase use`, and the Firebase web config.

## G. Run and test locally

Use VS Code Live Server or another local HTTP server. Do not use `file://`.
1. Open `public/index.html` using Live Server (or configure the hosting root for your intended public entry page).
2. Register a customer using the public signup page.
3. Confirm Authentication > Users contains the account.
4. Confirm Firestore > `users` contains a matching UID profile with role `customer`.
5. Sign in as customer and submit a test inquiry.
6. Submit a test order with an available product and stock.
7. Sign in as admin at `admin/admin-login.html`.
8. Test product/process management, inquiry status changes, order management, and dashboard.
9. Test that a customer cannot open admin pages or read another customer's order.
10. Test Storage upload after wiring the file inputs to the helper.

## Important limitations and security notes

- The app is plain HTML/JS, not React + Vite. The existing Firebase config is already wired for this architecture.
- `firebase/storage-upload.js` supplies secure reusable upload functions, but image file-input controls and image upload calls still need integration into the existing management forms.
- The dashboard currently uses one-time `getDocs()` reads. It is not a continuously live dashboard until its listeners are changed to `onSnapshot()`.
- The current checkout calculates totals in browser code. Firestore rules cannot reliably validate prices against the product catalogue or safely enforce inventory business logic. Before accepting real payments/orders at scale, move price calculation, stock reservation, and order creation into trusted Cloud Functions or another authenticated backend.
- The app currently has no public admin signup. This is intentional.
- Staff role is recognized in security rules for inquiry/order operations and Storage, but current admin page guards are admin-only. Staff UI authorization must be implemented before staff can use those pages.
- Do not set Firestore or Storage rules to `allow read, write: if true`.
- Test rules with Firebase Emulator Suite or Rules Playground before production use.
