
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-storage.js";

const firebaseConfig = {
    apiKey: "AIzaSyC2Nu00wCw_YXbnMZXB8yNUFEM3puJQTwY",
    authDomain: "betterbites-32937.firebaseapp.com",
    projectId: "betterbites-32937",
    storageBucket: "betterbites-32937.firebasestorage.app",
    messagingSenderId: "588150946807",
    appId: "1:588150946807:web:8bfb22e2869f5d2348ccf2"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;
