import { storage } from "./firebase.js";
import {
    ref,
    uploadBytes,
    getDownloadURL,
    deleteObject
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-storage.js";

const MAX_IMAGE_SIZE = 5 * 1024 * 1024;
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp"];

export async function uploadImage(file, folder, fileName = `${crypto.randomUUID()}-${file.name}`) {
    if (!file) throw new Error("Please choose an image.");
    if (!ALLOWED_TYPES.includes(file.type)) throw new Error("Only JPG, PNG, and WebP images are allowed.");
    if (file.size > MAX_IMAGE_SIZE) throw new Error("Image must be smaller than 5 MB.");
    if (!["products", "processes"].includes(folder)) throw new Error("Invalid upload folder.");

    const imageRef = ref(storage, `${folder}/${fileName}`);
    const snapshot = await uploadBytes(imageRef, file, { contentType: file.type });
    return {
        path: snapshot.ref.fullPath,
        url: await getDownloadURL(snapshot.ref)
    };
}

export async function uploadProfileImage(file, uid) {
    if (!uid) throw new Error("A signed-in user is required.");
    if (!file) throw new Error("Please choose an image.");
    if (!ALLOWED_TYPES.includes(file.type)) throw new Error("Only JPG, PNG, and WebP images are allowed.");
    if (file.size > MAX_IMAGE_SIZE) throw new Error("Image must be smaller than 5 MB.");

    const imageRef = ref(storage, `profiles/${uid}/${crypto.randomUUID()}-${file.name}`);
    const snapshot = await uploadBytes(imageRef, file, { contentType: file.type });
    return {
        path: snapshot.ref.fullPath,
        url: await getDownloadURL(snapshot.ref)
    };
}

export async function removeImage(path) {
    if (!path) return;
    await deleteObject(ref(storage, path));
}
